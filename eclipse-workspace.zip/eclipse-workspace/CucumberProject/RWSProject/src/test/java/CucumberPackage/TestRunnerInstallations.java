package CucumberPackage;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"FeatureDocument"}, //path of the feature file
                 glue = {"StepDefinations"},//path of the step defination
                 tags= {"@regression"},
                 format= {"pretty"},/*for reports*///pretty : we get report in console
                 dryRun = true,//first we need to keep false and execute there we get methods and then keep true and execute, default-true
                 monochrome = true,//to display plane text in console -true /special characters -false, default -false
                 strict=true)

public class TestRunnerInstallations {

}


/*
Feature driven development or Behavior driven development are same
Cucumber is a testing framework which supports Behavior Driven Development (BDD). It lets us define application behavior 
in plain meaningful English text using a simple grammar defined by a language called Gherkin. Cucumber itself is written in Ruby, 
but it can be used to “test” code written in Ruby or other languages including but not limited to Java, C# and Python.
what ever we write in feature that gets executed, code will not execute directly

Configurations and Installations:
1.create maven project
2.Cucumber API jar files
   <dependency>
			<groupId>info.cukes</groupId>
			<artifactId>cucumber-java</artifactId>
			<version>1.1.5</version>
			<scope>test</scope>
		</dependency>

		<dependency>
			<groupId>info.cukes</groupId>
			<artifactId>cucumber-jvm</artifactId>
			<version>1.1.5</version>
			<type>pom</type>
		</dependency>

		<dependency>
			<groupId>info.cukes</groupId>
			<artifactId>cucumber-junit</artifactId>
			<version>1.1.5</version>
			<scope>test</scope>
		</dependency>
		<dependency>
			<groupId>info.cukes</groupId>
			<artifactId>cucumber-jvm-deps</artifactId>
			<version>1.0.5</version>
		</dependency>
		<dependency>
			<groupId>net.masterthought</groupId>
			<artifactId>cucumber-reporting</artifactId>
			<version>1.0.0</version>
		</dependency>
		<dependency>
			<groupId>info.cukes</groupId>
			<artifactId>gherkin</artifactId>
			<version>2.12.2</version>
		</dependency>
		<dependency>
			<groupId>org.mockito</groupId>
			<artifactId>mockito-all</artifactId>
			<version>2.0.2-beta</version>
		</dependency>
		<dependency>
			<groupId>junit</groupId>
			<artifactId>junit</artifactId>
			<version>4.12</version>
			<scope>test</scope>
		</dependency>
3.Create a package with name “Cucumber” under src/test/java
4.Create a class with name “TestRunner” under Cucumber package
5.Create one Feature folder with in that folder create one file with “.feature” extension to write “gherkins” 
6.Under src/test/java create one package with “CucumberStepDefination” under that create one class to store all the methods
7.Go to help – Eclips Marketplace – search with “cucumber” 
    Install: Add Cucumber Plugin from below URL:http://cucumber.github.com/cucumber-eclipse/update-site

Execution flow - test runner,feature file, step defination, functions, targets(report)
      TestRunner - Cucumber Options(features,glue,tags,format,dryrun,monochrome,strict)
      FeatureFile - Gherkins(given,when,the,and,or,but)
      StepDefination - Functions

Gherkins - Gherkin is primarily used to write structured tests which can later be used as project documentation
Given - precondition to the test
When - test action that will be executed, test action means the user input action
Then - verification of the output with expected result
And - used to add conditions to your steps (both)
Or - any one 
But - used to add negative type comments. It is not a hard & fast rule to use but only for negative conditions. It makes 
      sense to use But when you will try to add a condition which is opposite to the premise your test is trying to set

Keywords:
Feature - Each Gherkin file begins with a Feature keyword.The idea of having a feature file is to put down a summary 
          of what we will be testing
Background - Background keyword is used to define steps which are common to all the tests in the feature file
             if we use background it will run as pre condition for all the testcases in feature file
             here we have only pre condition there is no after condition
Scenario - Each Feature will contain some number of tests to test the feature. Each test is called a Scenario and is 
           described using the Scenario keyword
Scenario Outline/Template -  can be used to run the same Scenario multiple times, with different combinations of values
       A Scenario Outline must contain an Examples
# - comments
@ - tags
| - data tables

Tags - @ - used to trigger the selective test cases
           tags are applied for feature file not to code 
           can be placed before feature and before scenario
           tags= {"@regression","@smaoke"}, ---- And
           tags= {"@regression,@smaoke"}, ---- Or

Hooks - which are blocks of code that run before or after each scenario. You can define them 
        anywhere in your project or step definition layers, using the methods @Before and @After. 
        Cucumber Hooks allows us to better manage the code workflow and helps us to reduce the code redundancy.
        pre and post condition for each and every testcase - @Before and @After
        
Execution order of Hooks - for single testcase multiple pre and post conditions, to execute those in order we use Execution order of Hooks concept
                           This extra parameter decides the order of execution of the certain hook
                           @Before(order = int) : This runs in increment order, means value 0 would run first and 1 would be after 0
                           @After(order = int) : This runs in decrements order, means apposite of @Before. Value 1 would run first and 0 would be after 1.

Tagged Hooks - tagging for a particular hook - @Before(“@smoke”)

In sprint automation [Feature driven development] - first we prepare feature and based on feature file we write code
Test Driven Development - first we write code and we call that code in @test

dryRun=false - missing method should be displayed and code will execute
dryRun=true  - code will not execute here, just it will show the methods

*/