package StepDefinations;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks 
{

	@Before(order=1)
	public void before1() 
	{
		System.out.println("before1");
	}
	@Before(order=2)
	public void before2() 
	{
		System.out.println("before2");
	}
	@After(order=2)
	public void after2() 
	{
		System.out.println("after2");
	}
	@Before(order=1)
	public void after1() 
	{
		System.out.println("after1");
	}
}
