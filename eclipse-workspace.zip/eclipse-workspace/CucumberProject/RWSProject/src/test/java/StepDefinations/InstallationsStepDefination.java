package StepDefinations;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InstallationsStepDefination 
{
	@Given("^user should be in home page of application$")
	public void user_should_be_in_home_page_of_application() throws Throwable {
	   System.out.println("hi this is karthik");
	}

	@When("^navigates to login page$")
	public void navigates_to_login_page() throws Throwable {
	   
	}

	@Then("^Message displayed Login Successfully$")
	public void Message_displayed_Login_Successfully() throws Throwable {
	   
	}

	@Given("^user should enter the insightsc(\\d+)m url$")
	public void user_should_enter_the_insightsc_m_url(int arg1) throws Throwable {
	   
	}

	@When("^Enter UserName and Password$")
	public void Enter_UserName_and_Password() throws Throwable {
	 
	}

	@When("^Click on Login Button$")
	public void Click_on_Login_Button() throws Throwable {
	   
	}

	@Then("^RWS Home page should be displayed$")
	public void RWS_Home_page_should_be_displayed() throws Throwable {
	    
	}


	


}
