package Maven.MavenProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Synchronization extends Browsers
{

	public static void main(String[] args) 
	{
		//Thread.sleep(3000/*milliseconds*/);
		//Common.manage().timeouts().implicitlyWait(30/*any measurements*/, TimeUnit.SECONDS/*need to mention static methods as seconds/minutes/hours (by using class(TimeUnit) we need to call these static methods)*/); //it will not wait for 30sec at every element,if the element find by 5sec it will not wait rest 25 sec.
		//WebDriverWait wait/*reference variable*/=new WebDriverWait(Common, 30/*seconds*/);/*class object*/ //it will not wait for 30sec at every element,if the element find by 5sec it will not wait rest 25 sec.
		//wait/*reference variable*/.until(ExpectedConditions/*class name*/.elementToBeClickable(gender)/*static method*/);
	}
	
	
	/*dynamic explicit wait*/
	
	public static void waitforElement(WebElement element, long time)
	{
		WebDriverWait wait=new WebDriverWait(Common, time);
		//wait.until(ExpectedConditions.elementToBeClickable(element));
		//wait.until(ExpectedConditions.elementToBeClickable(element));
	}

}

/*Synchronization meaning: when two or more components involved to perform any action, we expect these components 
  to work together with the same pace. The co-ordination between these components to run paralelly is called Synchronization.
  Synchronization (Wait) in Selenium has a great significant value.

Unconditional : synchronization indicates timeout value alone and makes tool to continue further only when specified time is elapsed.
     Thread.sleep(milliseconds) is the java native method (blind wait how many milli seconds we have given), 
                                this is a step level whereever we want there we have to give
     
Conditional : By using conditional synchronization we can specify timeout duration along with 
              some desired conditions to check and then throw an error if nothing happens
    Implicit wait : is a script level, when starting the program we given wait whereever the web elements required synchronization 
                    that implicit statement gets invoked and given seconds are allocating for synchronization.
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            How much it needed it takes rest of the time it will eliminate or skipping
            
    Explicit wait : is a step level where we get synchronization there we have to give explicit wait. If we want to use this 
                    wait we need create "WebDriverWait" class object we need to call static methods by class name "ExpectedConditions"
            public static void waitforElement(WebElement element, long time)
		    {
			WebDriverWait explicitlyWait = new WebDriverWait(driver, time);
			explicitlyWait.until(ExpectedConditions.elementToBeClickable(element));
		    }      		     
             waitforElement(SearchField, 30); //Explicitly Wait
             
      Static Methods in Explicit wait - AlertIsPresent(),ElementToBeSelected(),FrameToBeAvaliableAndSwitchToIt(),ElementToBeClickable(),
                                 TextToBePresentInElement(),TitleIs(),TitleContains(),VisibilityOfAllElements()
*/