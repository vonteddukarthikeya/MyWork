package Maven.MavenProject;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.Random;

public class Propertie 
{

	public static String path="./Testdata.properties";
	public static void main(String[] args) 
	{
	
	}
	
	public static String loaddata(String key) throws Exception
	{
		File/*class*/ f=new File(path);//load the file (from "java.io" package)
		FileInputStream/*class*/ fis=new FileInputStream(f);//to read the data from file path (from "java.io" package)
		Properties/*class*/ prop=new Properties();//to read the data from properties file
		prop.load(fis);//to load the properties file

		return prop.getProperty(key);//read the data
		
	}
	
	public int randomnumber() 
	{
		Random/*class*/ r=new Random();//to get random values (from "java.util" package)
		int rand=r.nextInt(9999);//to give some range

		return rand;
	}
}


/*
commonly used values we store in properties file. property file is one flat file its kind of note pad, 
here every data is represented in the form of key value place. 
right click on project -> New -> File and give extension as ".properties". 
For giving comments we can use (# or !). 
Before equals is key and after equals is value (domainmame=@GMAIL.COM). 
instead of "=" we can give space or ":" also.

Examples:
firstname=QA
lastnamme:test
domainmame=@GMAIL.COM
password password

we need to add the file path in top, "./" represents current project (public static String path="./Testdata.properties";)
Both key and values are strings so we have to change "void" to "String" then we get return statement

create an object for "File, FileInputStream and Properties", then load data and then in return statement add getproperty to get keys.
*/

