package Maven.MavenProject;

import org.openqa.selenium.chrome.ChromeDriver;

public class Maventheory 
{

	public static void main(String[] args) 
	{
		System/*class name*/.setProperty("webdriver.chrome.driver"/*key:standard key word and need to be in small letters only*/, "D:\\Selenium\\chromedriver.exe"/*value:should be the physical path of the drivers*/);
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in");

	}

}


//Maven is an build versioning control,everything it maintains in form of versions.here everything we take in groupid(package name) and actifactid(project name)
//in pom.xml we need to give groupid,actifactid and version,based on given information is going to load the information from maven centralised repository and loads into the current project
//file-new-maven-mavenproject-click on next-click on next-click on next-give groupid,actifactid-finish
//click on pom.xml-dependent jar files(selenium server,testng) are downloaded from "http://mvnrepository.com" and adding to the "dependencies/pom.xml" -we need to get groupid,actifactid,version from that link
//maven resposibilities need to run [mavenproject-runas-maven clean (build should be success) - maven install(build should get success)]
//if we are getting build fail windows-preferences-java-installed JRES - select and edit and jdk file location - apply
// dependicies are added by  groupid(package name) and actifactid(project name)
//in src/main/java we need to create all java classes and in src/test/java we need to create testng classes
//we cant execute the scripts in batch in java project but we can execute in batch by keeping in pom.xml


//testng is a java framework earlier junit, ng stands for next generation inspired by junit,used for unit,functional,integration and end to end testing
//in testng we dont have main methods and everything is represented in annotations (@before method,@after method and @test)
//testng.org is official site 
//testng has over junit 1.annotations(Before/After Suite and Group) 2.dependency test 3.grouping of test methods 4.multithreaded execution(parallel executions) 5.in built reporting framework
//suits and tests are configured or described mainly through xml files,here xml file is called execution engine
//for installing testng - go to help-eclipse market place-search for testng and install
//for checking eclipse is installed in our metion - windows- show view-others-java and check
