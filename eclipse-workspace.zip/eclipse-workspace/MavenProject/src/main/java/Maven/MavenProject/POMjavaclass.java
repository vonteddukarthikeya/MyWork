package Maven.MavenProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class POMjavaclass extends Synchronization
{
	Propertie pr=new Propertie();	
@FindBy(linkText="Sign in") public WebElement signIn;
@FindBy(id="email") WebElement email;
@FindBy(id="passwd") WebElement password;
@FindBy(id="SubmitLogin") WebElement submitLogin;
@FindBy(xpath=".//*[@id='center_column']/div[1]/ol/li") WebElement error;
@FindBy(id="email_create") WebElement createemail;
@FindBy(id="SubmitCreate") WebElement createsubmit; 
@FindBy(id="id_gender1") WebElement gender;
@FindBy(id="customer_firstname") WebElement customerfirstname;
@FindBy(xpath="//div[@class='required form-group']//input[@id='customer_lastname']") WebElement customerlastname;
@FindBy(id="firstname") WebElement firstname;
@FindBy(id="lastname") WebElement lastname;
@FindBy(id="company") WebElement company;
@FindBy(id="address1") WebElement address;
@FindBy(id="city") WebElement city;
@FindBy(id="postcode") WebElement postcode;
@FindBy(id="phone_mobile") WebElement mobile;
@FindBy(id="alias") WebElement alias;
@FindBy(id="submitAccount") WebElement submitAccount;


public POMjavaclass(WebDriver common) 
{
	PageFactory/*underpagefactory we have init*/.initElements/*static method to initialize the current class webelements */(common, this/*to call current page*/);
}


public void customerLogin() throws Exception
{   
	signIn.click();
	email.sendKeys(pr.loaddata("firstname")+pr.loaddata("lastnamme")+pr.randomnumber()+pr.loaddata("domainmame"));
	password.sendKeys("password");
	submitLogin.click();
}

public void customerRegistration() throws Exception
{
	
	createemail.sendKeys(pr.loaddata("firstname")+pr.loaddata("lastnamme")+pr.randomnumber()+pr.loaddata("domainmame"));
	System.out.println(email.getAttribute("value"));
	createsubmit.click();
	Thread.sleep(4000);
	//WebDriverWait wait=new WebDriverWait(Common, 30);
	//wait.until(ExpectedConditions.elementToBeClickable(gender));
	//waitforElement(gender, 30);//dynamic explicit wait calling
	gender.click();
	Thread.sleep(4000);
    customerfirstname.sendKeys(pr.loaddata("firstname"));
    Thread.sleep(4000);
	customerlastname.sendKeys(pr.loaddata("lastnamme"));
	password.sendKeys(pr.loaddata("password"));
	company.sendKeys("capgemini");
	address.sendKeys("4-23,chinnaplli,kondapuram,kadapa");
	city.sendKeys("kadapa");
	postcode.sendKeys("516464");
	mobile.sendKeys("8886544423");
	alias.sendKeys("Vonteddu");
	submitAccount.click();	
}



public String verifyLogin()
{
	return error.getText();
}

}
