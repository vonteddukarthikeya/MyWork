package Maven.MavenProject;

public class DBConnection
{
//steps to connect to the database

/*
 1.Register the Driver class
Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
*/

/*
 2.Create Connection
Connection con = DriverManager.getConnection ("url of database","username","password");
*/

/*
 3.Create Statement
Statement stmt = con.createStatement();
*/

/*
4.Execute Queries
ResultSet rs = stmt.executeQuery("select * from <table>");
while (rs.next())
{
System.out.println(rs.getString("username") + " " + rs.getString("password") + " "  + rs.getString("datecreated") + " " + 
                   rs.getString("noofattempts") + " " + rs.getString("result"));
                
username,password,datecreated,noofattempts,result  ------- columns from database table
}
*/

/*
5.Closing Connection
con.close();
*/
	
}