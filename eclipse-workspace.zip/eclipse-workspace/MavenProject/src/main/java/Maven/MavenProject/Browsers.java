package Maven.MavenProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Browsers 
{

	public static WebDriver Common;//static giving means without object we can use
	
	public static void browserLaunch(String browser,String url)
	{
		if(browser.equalsIgnoreCase("Chrome"))
		{
			System/*class name*/.setProperty("webdriver.chrome.driver"/*key:standard key word and need to be in small letters only*/, "D:\\Selenium\\chromedriver.exe"/*value:should be the physical path of the drivers*/);//before launch the browser we need to setup the driver path from respective browsers //system.set method ,setproperty is a static method and called by class name 
			Common=new ChromeDriver();
			//Commom.get("https://www.amazon.in");//get method is used to launch the application browser
		}
	    else if(browser.equalsIgnoreCase("Edge"))
		{
			System.setProperty("webdriver.edge.driver", "D:\\Selenium\\MicrosoftWebDriver.exe");
			Common=new EdgeDriver();
			//Commom.get("https://www.flipkart.com");
		}
		/*else if(browser.equalsIgnoreCase("IE"))
		{
		    System.setProperty("webdriver.ie.driver", "D:\\Selenium Tool\\IEDriverServer.exe");
		    Common=new InternetExplorerDriver();
			//Commom.get("https://www.amazon.in");
		}
		else if(browser.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "D:\\Selenium Tool\\geckodriver.exe");
			Common=new FirefoxDriver();
			//Commom.get("https://www.flipkart.com");
		}*/
		Common.get(url);
		Common.manage().window().maximize();
		//Common.manage().timeouts().implicitlyWait(30/*any measurements*/, TimeUnit.SECONDS/*need to mention static methods as seconds/minutes/hours (by using class(TimeUnit) we need to call these static methods)*/);
		
	}
	

	

}


