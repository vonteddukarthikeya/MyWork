package Maven.MavenProject;

import org.openqa.selenium.WebDriver;

public class Actions extends Browsers
{
	
 Actions a =new Actions();

 /*
  //browser slider
  for(int i=0;i<10;i++)
  {
  ((RemoteWebDriver)Common).executeScript("Window.scrollBy(0,100)");//vertical position
  }  
*/
}

/*
 Helps to perform keyboard or mouse events we use actions classes,representation "Actions a=new Actions(	);
 Action class methods
 1.moveToElement() - Moves the mouse to the specified element
 2.click() - Clicks the mouse at the last known mouse coordinates
 3.dragAndDrop(source,target) - Performs a drag-and-drop operation from one element to another
 4.clickAndHold()- Clicks and holds the mouse button at the last known mouse coordinates
 5.release() - Releases the mouse button at the last known mouse coordinates
 6.perform() - Performs the currently built action
 7.build() - Builds the sequence of actions
 8.contextClick() - Right-clicks the mouse at the last known mouse coordinates
 9.doubleClick() - Double-clicks the mouse at the last known mouse coordinates
 10.equals() - Determines whether the specified Object is equal to the current Object
 11.getHashCode() - Serves as a hash function for a particular type
 12.getType() - Gets the Type of the current instance
 13.toString() - Returns a String that represents the current Object
 14.sendKeys() - Sends a sequence of keystrokes to the browser
 15.autoSuggestion()
 16.dragAndDropBy(source, x-offset, y-offset) - Performs click-and-hold at the location of the source element, moves by a given offset, then releases the mouse.
 17.sendKeys(Keys.ENTER/RETURN)
 18.keyDown(Keys.CONTROL or Keys.SHIFT or Keys.ALT)
 19.keyUp(Keys.CONTROL or Keys.SHIFT or Keys.ALT)
 20.pause()
 21.tick()
 22.sendKeys(Keys.TAB)
 23.sendKeys(Keys.ESCAPE)
 24.sendKeys(Keys.DELETE)
 
 
 when you work with action classes using one event(method) we need to use ".perform()"
      example: a.moveToElement(xpath).perform();
 when you work with action classes using morethan one event(method) we need to use "build().perform()"
      example: a.moveToElement(xpath).click(xpath).build().perform();

*/