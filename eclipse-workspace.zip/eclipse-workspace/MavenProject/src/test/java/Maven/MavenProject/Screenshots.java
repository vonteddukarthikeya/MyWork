package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;

public class Screenshots extends Browsers
{
	
  @BeforeMethod
  public void beforeMethod() 
  {
	  
  }
 
//blindly taking screenshot of entire page with hardcoded screenshot name
  /*@Test
  public void f() throws IOException 
  {
      browserLaunch("Chrome", "https://www.axisbank.com");
	  File screenshot = ((TakesScreenshot)Common).getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(screenshot, new File("D:\\Users\\kvontedd\\Desktop\\Screenshots\\kkr.png"));
  }*/
  

 //based on condition taking screenshot with hardcoded screenshot name
  /*@Test
  public void g() throws IOException 
  {   
	  browserLaunch("Chrome", "https://google.com");
	  List<WebElement> links = Common.findElements(By.linkText("South Africa"));
	  if(links.size()==0)//if southafrica links are not presents and ==0 take a screenshot,if present dont take a screenshot
	  {
	  File screenshot = ((TakesScreenshot)Common).getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(screenshot, new File("D:\\Users\\kvontedd\\Desktop\\Screenshots\\southafrica.png"));
	  }
  }*/
  
  
//base on functionality name need to take the screenshots (drawback is when we run second time again it will be with the same name and overrided)
  /*@Test
  public void h() throws IOException 
  {   
	  browserLaunch("Chrome", "https://www.seleniumhq.org");
	  List<WebElement> links = Common.findElements(By.tagName("a"));
	  for(int i=0; i<links.size(); i++)
	  {
		  if(!links.get(i).getText().isEmpty())//clicked link is not empty
		  {
			  String linkname = links.get(i).getText();
			  links.get(i).click();
			  File screenshot = ((TakesScreenshot)Common).getScreenshotAs(OutputType.FILE);
			  FileUtils.copyFile(screenshot, new File("D:\\Users\\kvontedd\\Desktop\\Screenshots\\"+linkname+".jpeg"));
			  links = Common.findElements(By.tagName("a"));//page dom properties will be getting released so only we are repeating this again
		  }
	  }	  
  }*/
  
  
  
//getting screen shot with date and time used when running multiple times
  /*@Test
  public void i() throws IOException 
  {
      browserLaunch("Chrome", "https://www.axisbank.com");
      Date dte=new Date();
      DateFormat dateformat =new SimpleDateFormat("dd-MM-YYYY HH-mm-ss");
	  File screenshot = ((TakesScreenshot)Common).getScreenshotAs(OutputType.FILE);
	  FileUtils.copyFile(screenshot, new File("D:\\Users\\kvontedd\\Desktop\\Screenshots\\"+dateformat.format(dte)+".png"));
  }*/
  
   
//base on functionality name,so we need unique,we get it by date and time
  @Test
  public void j() throws IOException 
  {   
	  browserLaunch("Chrome", "https://www.seleniumhq.org");
	  List<WebElement> links = Common.findElements(By.tagName("a"));
	  System.out.println(links.size());
	  for(int i=0; i<links.size(); i++)
	  {
		  if(!links.get(i).getText().isEmpty())//clicked link is not empty
		  {
			  String linkname = links.get(i).getText();
			  links.get(i).click();
			  if(Common.getTitle().contains("Download"))
			  {
			    DateFormat dateformat =new SimpleDateFormat("dd-MM-YYY HH-mm-ss");
			    Date dte=new Date();
			    File screenshot = ((TakesScreenshot)Common).getScreenshotAs(OutputType.FILE);
			    FileUtils.copyFile(screenshot, new File("D:\\Users\\kvontedd\\Desktop\\Screenshots\\"+linkname+"_"+dateformat.format(dte)+".jpeg"));
			  }
			  
			  links = Common.findElements(By.tagName("a"));//page dom properties will be getting released so only we are repeating this again
		  }
	  }	 
  }
  
  
  @AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}


/*
   reason of taking screenshot is for proof.

   webdriver is providing interface "TakeScreenshot" for capturing the screenshot of webapplication and this interface provides 
   one method name as "getScreenshotAs()" to capture screenshot in instance of driver. This "getScreenshotAs()" method takes 
   argument of type "OutputType.File" or "OutputType.BASE64" OR "OutputType.BYTES" so that we could return captured screenshot 
   in filetype or Base64 String type or in Raw Bytes
       syntax :  File scrnshot = ((TakeScreenshot)Common).getScreenshotAs(OutputType.FILE);
       
   after taking screenshot by using "getScreenshotAs()" method need to copy the file in our desktop or file system.
   so for this purpose we use "copyFile()" method, and this method contains class "FileUtils" from org.apache.commons.io.FileUtils,
   two arguments we are passing 
         syntax for placing file in filesystem : FileUtils.copyFile(scrnshot,new File("path"));
                                                 scrnshot //source temp variable where we have taken screenshot
                                                 new File("path") //destination where to store
                                                 
  to get system date, we need to create a class "Date" it is from java.util package and DateFormat class is from java.text package 
*/


/*
Into the classes (Listener,Retry,RetryListener) we will be implemented some interfaces,interfaces having some abstract methods.

Listener : suppose the script is getting failed or passed or skipped what to do,script started execution what message we have 
           to display all this we need to give in listener class in implementing the "iTestListener" interface
           
Abstract method in iTestListener interface : onTestStart,onTestSuccess,onTestFailure,onTestSkipped,
                                             onTestFailedButWithinSuccessPercentage,onStart,onFinish

We need to configure the Listener and RetryListener classes in "xml" file under "listeners" tag. 
   they put one eye contact on current class execution
*/


/*
on test success we take screenshots and when test gets failed at that time we need to retry it for morethan onetime
   (failure reason : network bandwidth,database servers down,application servers down,locator might be changed)

retryListener class we use "IAnnotationTransformer" interface and abstract method is "transform"
*/


/*
 retry class we use "IRetryAnalyzer" interface and abstract method "retry()"
*/