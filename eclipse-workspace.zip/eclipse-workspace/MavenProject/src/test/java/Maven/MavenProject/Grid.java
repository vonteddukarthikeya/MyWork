package Maven.MavenProject;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Grid
{

	public static void main(String[] args) throws MalformedURLException
	{
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setBrowserName("chrome");
		cap.setPlatform(Platform.WINDOWS);
		
		ChromeOptions options = new ChromeOptions();
		//options.merge(cap);
		
        String hubUrl="http://localhost:4444/wd/hub";
        WebDriver driver = new RemoteWebDriver(new URL(hubUrl), cap);
        driver.get("https://www.amazon.com");
        System.out.println(driver.getTitle());
	}
}

/*
Grid is one of the component in selenium, when we are using RC or WebDriver we use GRID. For writing the browser based 
     scripts we use RC or WebDriver.
Grid is used for implementing distributed testing.
In grid we have a server called HUB and HUB is connected to multiple terminals called NODES(clients)
Each of these can be running on same OS or Diffrent OS.Similarly they can be using the same browsers or different browsers.
Using GRID we can perform cross Browser and Cross platform testing serially and paralally.

Grid when implemented with webDriver is called GRID2
when it was implemented with RC is called GRID1

Note:Grid is more compatable with TestNG framework,because TestNG supports both serial and parallel testing.
     where as Junit supports only serial testing.

Process of creating of HUB:
open cmd prompt in the machine which should be converted as HUB.
with the help of selenium standalone server only we convert as HUB and Node
copy the selenium standalone server path
java -jar selenium standalone server path -role hub
console view : http://localhost:4444/grid/console
               4444 is a port number which is the default port number for a HUB
               5555 is the default port number for a NODE
Note:when using same machine we use "localhost:" or "SystemIpaddress:"

Process of creating of NODE:
open cmd prompt in the machine which should be converted as NODE.
with the help of selenium standalone server only we convert as HUB and Node
copy the selenium standalone server path
java -jar selenium standalone server path -role node -hub http://localhost:4444/grid/register -port 6666
console view : http://localhost:4444/grid/console
               4444 is a port number which is the default port number for a HUB
               5555 is the default port number for a NODE
               
 
Grid Architecture:
                                                                                                        chromedriver.exe,geckodriver.exe,IEDriverServer.exe
DesiredCapabilities                       __Json wire protocol_________Node1(windows)________________ IE,FF,Chrome,Safari
platform/browser/version                                                 chrome,ff,ie,safari
                                                                                                     chromedriver.exe,geckodriver.exe,IEDriverServer.exe
java+WebDriver__________________Hub Server__Json wire protocol___________Node2(mac)________________ IE,FF,Chrome,Safari
                                                                          chrome,ff,ie,safari
RemoteWebDriver                                                                                         chromedriver.exe,geckodriver.exe,IEDriverServer.exe
                                          __Json wire protocol___________ Node3(linux)________________ IE,FF,Chrome,Safari
                                                                           chrome,ff,ie,safari
 
 
Note:
Save Hub and Node files as .bat to open and run without opening in cmd


Hub.bat file
java -jar "selenium standalone server path" -role hub

Node.bat file
java -Dwebdriver.chrome.driver="path" -Dwebdriver.gecko.driver="path" -jar "selenium standalone server path" -role node -browser 
      browserName=safari,maxInstances=2 -browser
      browserName=chrome,maxInstances=3 -hub http://localhost:4444/grid/register -port 6666


 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
*/