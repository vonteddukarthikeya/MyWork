package Maven.MavenProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PageObjectModelPOM extends Browsers
{

  POMjavaclass pomclass;
  
  
  @Test
  public void f() throws Exception 
  {
	  pomclass=new POMjavaclass(Common);//created object of the page and create constructor
	  pomclass.customerLogin();//calling main method using page object
	  Assert.assertEquals("Authentication failed.", pomclass.verifyLogin());//to verify the actual with the expected we use Assert.assertEquals
	  Common.navigate().refresh();
	  pomclass.customerRegistration();
	
  }
  
  @BeforeMethod
  public void beforeMethod() 
  {
	  browserLaunch("Chrome","http://automationpractice.com/index.php");
  }

  @AfterMethod
  public void afterMethod() 
  {

  }

}


/*Page Object Model is a design pattern to create Object Repository for web UI elements.
 
POM helps to make the code more readable, maintainable, and reusable. 
(ex:The chief problem with script maintenance is that if 10 different scripts are using the same page element, 
with any change in that element, you need to change all 10 scripts. This is time consuming and error prone. 
A better approach to script maintenance is to create a separate class file which would find web elements, 
fill them or verify them. This class can be reused in all the scripts using that element. 
In future, if there is a change in the web element, we need to make the change in just 1 class file and not 10 different scripts. )

we need to create one sample java class (ie called page factory) there we store all elements

by using "@FindBy(linkText="Sign in") WebElement signIn;" returntype"WebElement" name"signIn"; 
and we can use this variable outside means we can give "public" also (ex:@FindBy(linkText="Sign in") public WebElement signIn;)

need to call the methods in testng class(pom) from java class(page factory), 
we need to use "has a" relation and that should be defined before @Test method.

when we get nullpoint exception : in testng class(pom) once we must initialize the webelements, we need to use constuctors,
"init"static method to initialize the current class webelements
public POMjavaclass(WebDriver common) 
{
	PageFactory.initElements(common, this);
}
underpagefactory we have init
static method to initialize the current class webelements(initElements)
to call current page(this)

*/