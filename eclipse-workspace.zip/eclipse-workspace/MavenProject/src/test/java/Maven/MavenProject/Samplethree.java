package Maven.MavenProject;

import org.testng.annotations.Test;

import junit.framework.Assert;

public class Samplethree 
{
	
  @Test
  public void orange() 
  {
	  System.out.println("orange");
  }
  
  @Test(dependsOnMethods= {"orange"})
  public void white() 
  {
	  System.out.println("white");
	  //Assert.assertTrue(false);
  }
  
  @Test(dependsOnMethods= {"white"})
  public void black() 
  {
	  System.out.println("black");
  }
  
  @Test(dependsOnMethods= {"black"})
  public void green() 
  {
	  System.out.println("green");
  }
  
}


//Assert.assertTrue(false); -  forcelly making fail