package Maven.MavenProject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class BrokenLinks extends Browsers{
  

  @BeforeMethod
  public void setup() 
  {
	 browserLaunch("Chrome", "http://newtours.demoaut.com");
  }
  
  
  @Test
  public void brokenLinks() throws Exception 
  {
	 
	 List<WebElement> links = Common.findElements(By.tagName("a"));//to find entire page links store into links
	 System.out.println("Total Links :" + links.size());//printing the size
	 
	 for(int i=0;i<links.size();i++)
	 {
		
		 String url=links.get(i).getAttribute("href");//to find web element inner property (here "href" is inner property) we use "getAttribute" and store into url
		 
		 verifyLinkActive(url);//writing one function and passing argument of the url
	 }
  }
  
  public static void verifyLinkActive(String linkUrl) throws Exception//url is string type, linkUrl holds the href properties
	{
      
			URL url = new URL(linkUrl);//linkUrl is given to the URL class constructor, create an object for URL class
			 
			 HttpURLConnection httpURLConnect=(HttpURLConnection)url.openConnection();// url object must give to the HTTPURLConnection
			 
			 httpURLConnect.setConnectTimeout(3000);//waiting for connection to connect
			 
			 httpURLConnect.connect();//connect
			 
			 if(httpURLConnect.getResponseCode()==200)
			 {
			     System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage());
			 }
			if(httpURLConnect.getResponseCode()==HttpURLConnection.HTTP_NOT_FOUND) 
			 {
			     System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage() + " - "+ HttpURLConnection.HTTP_NOT_FOUND);
			  }
		} 
 
  
 
  @AfterMethod
  public void teardown() 
  {
	  Common.quit();
  }

}


//broken links means some links are not working properly,to findout the broken links we need two classes (url class and httpurlconnection), these two classes are from java.net package (jave 8 api)
//html tag name for link "<a></a>"
//mandatory property for link "href"
//with this url taking all the angular tag href properties what the href contains url that urls will be assigned to the urlconstructor,by using getattribute we capture href inner properties and href attribute value passing as argument for the constructor url class 
//So this url class will be  passing to https urlconnection in connecting to the server, then server gets some response with that we can find what type of link broken and gives that error
//how can we get response codes and messages : based on your link href and attribute property when giving to the httpurlconnection the establish the connection to the server from server we get the response
