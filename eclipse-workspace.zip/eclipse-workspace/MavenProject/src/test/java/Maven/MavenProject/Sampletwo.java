package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;

public class Sampletwo extends Browsers
{
	
  @Test(groups= {"smoke","regression"})
  public void launchMethod2() 
  {
	  Common.findElement(By.id("twotabsearchtextbox")).sendKeys("Harry Potter");
	  Common.close();
  }
  
  
  @BeforeMethod (groups= {"smoke","regression"})
  @Parameters("Browser")
  public void startProcess(String browsertype) throws InterruptedException 
  {
	  browserLaunch(browsertype, "https://www.amazon.in");
  }

  
  
  @AfterMethod
  public void endProcess() 
  {
	 Common.close();
  }
  

}



