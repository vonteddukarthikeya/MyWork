package Maven.MavenProject;

public class Log4j 
{

}

/*
 In test case we have number of steps for each step what was happening to know we must generate execution logs
 to get log information we must create one "properti" file and we need to add the jar file of the log4j (dependency in pom.xml)
 
properti file :
#Define the root logger with appender file
log4j.rootLogger= INFO,FILE,stdout//generating information in console"stdout" and in external file "File"
#Define the file appender
log4j.appender.FILE=org.apache.log4j.FileAppender//appending log4j in external file
log4j.appender.FILE.File=log4jFile.out//log information is generated in this file and stored permanently
log4j.appender.FILE.Append=true//all log information should be stored in same file
log4j.appender.FILE.layout=org.apache.log4j.PatternLayout//pattern layout
log4j.appender.File.layout.ConversionPattern=%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L -%m%n//conversion pattern
log4j.appender.FILE.MaxFileSize=4MB//maximum size
log4j.appender.FILE.MaxBackupIndex=9//if 4mb is not sufficient it increases max 9mb
#Direct log messages to stdout
log4j.appender.stdout=org.apache.log4j.ConsoleAppender//appending the log4j file in console window
log4j.appender.stdout.stdout=System.out//log information is generated in this console and stored temporarely
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout//apttern layout
log4j.appender.stdout.layout.ConversionPattern=%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L -%m%n//conversion pattern


In base class we need to call this property file
 	    String log4jConfigPath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfigPath);//configure is a method and through class name "PropertyConfigurator"


In main testng(driver) class and where ever we need we have to config
   inside the class outside the method we need to create logger class object
   public static final Logger log=Logger.getLogger(TC001_VerifyAddUserDetails.class.getName());
   log.info("Started ----- TC001_VerifyAddUserDetails -----");
*/