package Maven.MavenProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class GroupOfLinks extends Browsers
{


	
	int count=0;


	@BeforeMethod
	public void setup() 
	{
	
		browserLaunch("Chrome", "https://www.hdfcbank.com");
	}
	

/*all links (hidden and visible)*/
	@Test
	public void linkTesting1()
	{
	 List<WebElement> str = Common.findElements(By.tagName("a"));//multiple web elements interaction we use "findElements" return type is "List<WebElement>" 
		System.out.println("Total Links in A page including empty Links is ..."+str.size());
		for(int i=0;i<str.size();i++)
			{		
			        
					String links = str.get(i).getText();//getting first index "get(i)" out of all and storing in string type
					System.out.println(links);
					str = Common.findElements(By.tagName("a"));				
			}	
		
	}
	
/*dont want to print the hidden links only want to print the visible links*/
	@Test
	public void linkTesting2()
	{
	 List<WebElement> str = Common.findElements(By.tagName("a"));//multiple web elements interaction we use "findElements" return type is "List<WebElement>" 
		System.out.println("Total Links in A page including empty Links is ..."+str.size());
		for(int i=0;i<str.size();i++)
			{		
			if (!str.get(i).getText().isEmpty())//condition to get only visible links
			{ 
				    count++;//to get the count of visible links
					String links = str.get(i).getText();//getting first index "get(i)" outof all and storing in string type
					System.out.println(links);
					str = Common.findElements(By.tagName("a"));	
			}
			}	
		System.out.println("Total net Links present in page is .... "+count);
		
	}
	
	
	@AfterMethod
	public void teardown() 
	{
		Common.quit();
		
	}

}

//when page gets refresh web elements will not load, automatically at that time we get error (error name : stale element reference) after execution to overcome that : we need to redefine the same element at last which is written in starting.