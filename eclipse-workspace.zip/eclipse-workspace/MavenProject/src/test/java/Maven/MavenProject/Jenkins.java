package Maven.MavenProject;

public class Jenkins 
{

}


/*
Jenkins are used for continuous integration. jobs need to be configured
need to install jenkins "https://jenkins.io" and click on download button and install
default port for jenkins is "localhost:8080", instead of localhost we can give our ip address also
enable auto refresh : used to refresh the page for every 7 seconds the page will refesh
manage jenkins - manage users (update,delete, create users)
manage jenkins - configure global security - we need to install "role-based" plugin - click that radio button in configure global security(restrict the user only for specific options to show)
plugins will be in this  (manage jenkins-manage plugins)
manage jenkins - manage and assign roles (handle permissions by creating roles and assigning them to users/group)

how to create a job:
click on new item - give some name and select frestyle project - click on "ok"
gray color - status - not build	
pass -blue color
fail -red color
yellow - weather color 
To execute the build we need to click on "schedule a build for job1" icon

how to configure the jobs:
next to "Name" coloumn we have down arrow we need to click on that and click on "configure" link
tabs under configure are : General,Source Code Management,Build Triggers,Build Environment,Build,Post build Actions
Source code management - from where we want to take code (git,none(eclipse),subversion)
Build - invoke top-level Maven targets 
        goals - install test
	    POM - pom xml path
Build Triggers - Build periodically - Schedule (minute,hour,month,day of the month,day of the week)
Post-build Actions - after build execution what we have to do (generate the reports like html,testng) 
 
Taking source code from Eclipse:
1.before running in jenkins we have to make sure our project is working perfectly or not
2.tetsng class must convert into xml file
3.run the code from xml file
4.we need to configure the xml file in pom.xml file
  maven-compiler-plugin
  maven-surefire-plugin
  	<build>
		<plugins>
			<plugin>
				<groupId>org.apache.maven.plugins</groupId>
				<artifactId>maven-compiler-plugin</artifactId>
				<version>3.8.0</version>
				<configuration>
					<source>1.8</source>
					<target>1.8</target>
				</configuration>
			</plugin>
			<plugin>
				<groupId>org.apache.maven.plugins</groupId>
				<artifactId>maven-surefire-plugin</artifactId>
				<version>2.19.1</version>
				<configuration>
					<suiteXmlFiles>
						<suiteXmlFile>Firsttestng.xml</suiteXmlFile>
					</suiteXmlFiles>
				</configuration>
			</plugin>
		</plugins>
	</build>
5.run the goals- right click on pom.xml - run as(maven clean,install,test)
6.now open the jenkins and go to configure section
  Source code management - none
  Build - invoke top-level Maven targets
          maven version - maven name [after 8th step we get this] 
	      goals - clean install test
	      POM - pom xml path
7.click on apply and save
8.global settings [manage jenkins-global tool configuration], there we need to configure JDK,Git,Maven
9.click on "build scheduled"

Taking source code from GitHub:
1.push our code in github, instead of keeping in folder we need post all the project files without folder
2.select "git" radio button from Source Code Management
3.now open the jenkins and go to configure section
  Source code management - git
  Build - invoke top-level Maven targets
          maven version - maven name [after 8th step we get this] 
	      goals - clean install test
	      POM - pom.xml
4.click on apply and save

Email configuration:
1.manage jenkins - configure system - email notification
2. SMTP server - we need to specify out server (example: smpt.gmail.com)   [based on organisation]
   Default user e-mail suffic - @gmail.com   [based on organisation]
3.click on advanced
4.select "Use SMTP Authentication" "Use SSL" "Test configuration by sending test e-mail" check boxes
5.username : my email id (kr05061993@gmail.com)
  password : my password
  SMTP Port : port number for gmail (465)
  Text email recipient : to whome do we want to send the email that email id we need to give
6.click on "Test Configuration" we  get "email was successfully sent"
7.click on apply and save
8.check in email recipient - mail has come or not
9.now open the jenkins and go to configure section
   Post-build Actions - Email Notification
   Recipients - to whome this mail have to sent [kr0506@gmail.com karthik@gmail.com kkr@gmail.com]
   select "send email for every unstable build" checkbox
10.click on apply and save


Reports configuration:
1.Need to add "Extent Report" plugin to get extent reports and to get html reports we need to add "HTML Report" plugin
2.now open the jenkins and go to configure section
   Post-build Actions - Publish HTML reports
   HTML directory to archive - 
   Index page[s] -
   Index page title[s] (Optional)
   Report title
3.click on apply and save

*/
