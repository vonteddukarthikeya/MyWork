package Maven.MavenProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SingleLink extends Browsers
{



	@BeforeMethod
	public void starting()
	{

		browserLaunch("Chrome", "https://google.com");
		Common.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
	}
	
	
	
	
	@Test()
	public void linktesting()
	
	 {
		String expval="Google Images";
		
		Common.findElement(By.linkText("Images")).click();//single web element interaction we use "findElement"	return type is "WebElement"
	
		Reporter.log("Clicked on Image Link");
		String actval=Common.getTitle();
		
		Assert.assertEquals(actval, expval);//when we are clicking and comparing only we need to use the assert.assertequals

	 }
	
	
	@AfterMethod
	public void ending()
	{
		Common.close();
	}

}
