package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;

public class WebCalendars extends Browsers
{

  @BeforeMethod
  public void beforeMethod() 
  {
	  browserLaunch("Chrome", "https://www.tripadvisor.in/");
  }
  
  @Test
  public void f() 
  {
	  Common.findElement(By.xpath("	")).click();
	  String date = "11-Nov 2018";
	  String[] splitter = date.split("-");
	  String inday = splitter[0];
	  String inmonth = splitter[1];
	  selectDate(inday,inmonth);
	  
	  Common.findElement(By.xpath("	")).click();
	  String date1 = "11-Dec 2018";
	  String[] splitter1 = date.split("-");
	  String outday = splitter[0];
	  String outmonth = splitter[1];
	  selectDate(outday,outmonth);
  }
  
  private void selectDate(String month_year, String day) 
  {
	List<WebElement> dateelements = Common.findElements(By.xpath("//div[@class='rsdc-months']/span/span[1]"));
	System.out.println(dateelements.size());
	for(int i=0; i<dateelements.size(); i++)
	{
		System.out.println(dateelements.get(i).getText());
		if(dateelements.get(i).getText().equals(month_year))
		{
			List<WebElement> days = Common.findElements(By.xpath("div[@class='rsdc-months']/span["+(i+1)+"]/span[1]"));
			for(WebElement d : days)
			{
				System.out.println(d.getText());
				if(d.getText().equals(day))
				{
					d.click();
					return;
				}
			}
		}
	}
	
	
	WebDriverWait wait=new WebDriverWait(Common,60);
	wait.until(ExpectedConditions.elementToBeClickable(Common.findElement(By.xpath("html/body/span/div[3]/div/div[2]/div[1]")))).click();
	wait.until(ExpectedConditions.elementToBeClickable(Common.findElement(By.xpath("html/body/span/div[3]/div/div[2]/div[1]")))).click();
	
	selectDate(month_year, day);
  }

@AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}


