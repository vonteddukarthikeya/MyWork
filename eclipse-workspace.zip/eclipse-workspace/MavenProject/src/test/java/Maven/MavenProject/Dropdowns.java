package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class Dropdowns extends Browsers
{
 
  @BeforeMethod
  public void beforeMethod() 
  {
	  
  }

 /*traditional dropdown using send keys*/
  @Test
  public void a() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.amazon.in");
	  Common.findElement(By.id("searchDropdownBox")).sendKeys("Books");//send keys
	  Common.findElement(By.id("twotabsearchtextbox")).sendKeys("Harry Potter");
	  Common.findElement(By.className("nav-input")).click();
	  String actval = Common.getTitle();
	  String expval = "Amazon.in: Harry Potter: Books";
	  Assert.assertEquals(actval, expval);
  } 
  
  
  /*traditional dropdown using findelement and findelements*/
  @Test
  public void b() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.amazon.in");
	  WebElement header = Common.findElement(By.id("searchDropdownBox"));
	  List<WebElement> items = header.findElements(By.tagName("option"));
	  for (int i=0; i<items.size(); i++)
	  {
		  if(items.get(i).getText().equalsIgnoreCase("Appliances"))
		  {
			  items.get(i).click();
		  }
	  }
  }
  
  /*To print all the options in dropdown using findelement and findelements*/
  @Test
  public void b1() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.amazon.in");
	  WebElement header = Common.findElement(By.id("searchDropdownBox"));
	  List<WebElement> items = header.findElements(By.tagName("option"));
	  for (int i=0; i<items.size(); i++)
	  {
		 System.out.println(items.get(i).getText()); 
	  }
  }
  
  
  /*select onebyone option and validate the selected option is correct or not using findelement and findelements*/
  
  @Test
  public void b2() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.newtours.demoaut.com");
	  Common.findElement(By.linkText("REGISTER")).click();
	  WebElement locator = Common.findElement(By.name("country"));
	  List<WebElement> items = locator.findElements(By.tagName("option"));
	  for(int i=0; i<items.size(); i++)
	  {
		  items.get(i).click();
		  if(items.get(i).isSelected())
		  {
			  System.out.println(items.get(i).getText()+" --- is Active");
		  }
		  else
		  {
			  System.out.println(items.get(i).getText()+" --- is Inactive");
		  }
		  
	  }
	  
  }
  
  
  /*traditional dropdown using select class*/ 
  @Test
  public void c() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.amazon.in");
	  WebElement locator = Common.findElement(By.id("searchDropdownBox"));
	  Select select=new Select(locator);
	  select.selectByIndex(0);
	  select.selectByValue("search-alias=alexa-skills");
	  select.selectByVisibleText("Books");
	  Common.findElement(By.id("twotabsearchtextbox")).sendKeys("Harry Potter");
	  Common.findElement(By.className("nav-input")).click();
	  String actval = Common.getTitle();
	  String expval = "Amazon.in: Harry Potter: Books";
	  Assert.assertEquals(actval, expval);
  }
  
  
  /*To print all the options in dropdown using select class*/
  @Test
  public void c1() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.amazon.in");
	  WebElement locator = Common.findElement(By.id("searchDropdownBox"));
	  Select select=new Select(locator);
	  List<WebElement> items = select.getOptions();//to get all the options in the dropdown
	  for (int i=0; i<items.size(); i++)
	  {
		 System.out.println(items.get(i).getText()); 
	  }
  }
  
  
  /*select onebyone option and validate the selected option is correct or not using select class*/
  @Test
  public void c2() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.newtours.demoaut.com");
	  Common.findElement(By.linkText("REGISTER")).click();
	  WebElement locator = Common.findElement(By.name("country"));
	  Select select=new Select(locator);
	  List<WebElement> items = select.getOptions();
	  for(int i=0; i<items.size(); i++)
	  {
		  items.get(i).click();
		  if(items.get(i).isSelected())
		  {
			  System.out.println(items.get(i).getText()+" --- is Active");
		  }
		  else
		  {
			  System.out.println(items.get(i).getText()+" --- is Inactive");
		  }
		  
	  }
  }
  

  /*traditional dropdown using Actions*/ 
  
  
  /*traditional dropdown using javascript executers*/ 
  
  
  /*bootstrap dropdown position getting changed from place to other*/
  @Test
  public void d() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.bbc.com");
	  Common.findElement(By.xpath(".//*[@id='orb-nav-more']/a")).click();
	  WebElement locator = Common.findElement(By.xpath(".//*[@id='orb-panel-more']/div"));
	  List<WebElement> items = locator.findElements(By.tagName("a"));
	  for(int i=0; i<items.size(); i++)
	  {
		  String actval = items.get(i).getAttribute("innerHTML");
		  if(actval.equals("Radio"))
		  {
			  items.get(i).click();
			  break;
		  }
	  }
	  
  }
  
  /*bootstrap dropdown selecting multiple checkboxes*/
  @Test
  public void f() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://www.itidabhoi.org/demo/bootstrap-multiselect-dropdown");
	  Common.findElement(By.xpath(".//*[@id='framework_form']/div[1]/div/button")).click();	  
	  Thread.sleep(4000);
	  WebElement locator = Common.findElement(By.xpath(".//*[@id='framework_form']/div[1]/div/ul"));
	  List<WebElement> items = locator.findElements(By.tagName("a"));
	  for(int i=0; i<items.size(); i++)
	  {
		 //System.out.println(items.get(i).getText()); 
		 // items.get(i).click();
		  if(items.get(i).getText().equalsIgnoreCase("Zend"))
		  {
			  items.get(i).click();
		  }
		  else if(items.get(i).getText().equalsIgnoreCase("YII"))
		  {
		  items.get(i).click();
	      }
	  }
	
  }
  
  
  @AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}

//how to find traditional dropdown and bootstrap dropdown - if we have "select and options" as header then it is traditional and if we see "ul and li" then it is bootstrap
//we cant use "select class" because we dont have select and option tags for bootstrap dropdowns