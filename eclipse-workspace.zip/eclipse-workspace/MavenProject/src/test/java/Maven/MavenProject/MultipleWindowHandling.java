package Maven.MavenProject;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MultipleWindowHandling extends Browsers
{
  
  @BeforeMethod
  public void beforeMethod() 
  {
	  
  }
  
  @Test
  public void f() throws InterruptedException 
  {
	  browserLaunch("chrome", "https://www.hdfcbank.com");
	  System.out.println(Common.getTitle());
	  String loginWindow = Common.getWindowHandle();//method to get single window handle
	  System.out.println("Parent window is"+ loginWindow);
	  Common.findElement(By.xpath(".//*[@id='loginsubmit']")).click();
	  Set<String> netbankingWindow = Common.getWindowHandles();//method to get multiple window handle //set will not allow duplicate values
	  System.out.println("Child window is "+ netbankingWindow.size());
	  Iterator<String> itr = netbankingWindow.iterator();
	  while(itr.hasNext())
	  {
		  String currentWindow = itr.next();
		  System.out.println("Windows are"+currentWindow);
		  if(!currentWindow.equals(loginWindow))
		  {
			Common.switchTo().window(currentWindow);
			System.out.println(Common.getTitle());
		  }
	  }
	  Common.manage().window().maximize();
	  Common.findElement(By.xpath("html/body/div[4]/div[2]/div[1]/a")).click();
	  Common.close();
	  Common.switchTo().window(loginWindow);
	  System.out.println(Common.getTitle());
  }

  @AfterMethod
  public void afterMethod() 
  {
	 Common.quit();
  }

}

//When we are navigating from one window to another window (example from window A to B to C) there we need to use "switchTo" [syntax: Common.switchTo().window(handle/name);]
          //window handle id will be unique and it is alpha numaric,with this only we can switch from one window to another window
          //if we want to get one window handle id we go with : getWindowHandle(); method [return type is String]
          //if we want to get multiple window handle id we go with : getWindowHandles(); method  [retuen type is Set<String>], set will not allow duplicate values
//when we are using sets and lists  we have to use cursors and iterators    