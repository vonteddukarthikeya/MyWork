package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;

public class Sampleone extends Browsers
{
	
	
  @Test(groups= {"regression","smoke"})
  public void launchMethod1()  
  {
    
    System.out.println(Common.getTitle());
    Common.close();
    
  }
  
  
  @BeforeMethod(groups= {"regression","smoke"})
  @Parameters("Browser"/*name which is given in xml file in parameter tag ex:<parameter name="Browser" value="Chrome"></parameter>*/)
  public void startProcess(String browsertype/*we can give any name*/) throws InterruptedException 
  {
	  browserLaunch(browsertype, "https://www.amazon.in");
  }
  

  @AfterMethod
  public void endProcess() 
  {
	  Common.close();
  }
  

}


