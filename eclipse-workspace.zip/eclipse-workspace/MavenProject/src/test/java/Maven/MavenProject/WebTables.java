package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.List;

import org.jboss.netty.util.internal.SystemPropertyUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;

public class WebTables extends Browsers
{

  @BeforeMethod
  public void beforeMethod() 
  {
	  browserLaunch("Chrome", "http://www.webdatacommons.org/webtables/");
  }

  //to print entire table data
  @Test
  public void f() 
  {
	   List<WebElement> tablerowcollection = Common.findElements(By.xpath("//table[1]/tbody/tr"));
	   System.out.println("Table Row size : "+tablerowcollection.size());
	   for(WebElement trElement : tablerowcollection)//"tablerowcollection" holds all the rows and giving onebyone to "trElement" (to iterate all the rows we are writing this for each loop)
	   {
		   List<WebElement> tabledatacollection = trElement.findElements(By.tagName("td"));
		   System.out.println("Table data size:"+tabledatacollection.size());//to iterate all the data
		   
		   for(WebElement tdElement : tabledatacollection)
		   {
			   
			   System.out.println(tdElement.getText());
			   
		   }
		   
	   }
  }
  
  @AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}

//html tag name [table- table body(tbody) - table headers(th) -rows(tr) - data(td)]