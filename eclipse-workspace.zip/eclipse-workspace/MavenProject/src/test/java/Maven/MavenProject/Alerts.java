package Maven.MavenProject;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Alerts extends Browsers
{
 
  @BeforeMethod
  public void beforeMethod() 
  {
	 
  }

/*java base alert*/  
  @Test
  public void f() throws InterruptedException 
  {
	  browserLaunch("Chrome", "http://demo.guru99.com/test/delete_customer.php");
	  Common.findElement(By.name("cusid")).sendKeys("53920");
	  Common.findElement(By.name("submit")).submit();
	  Alert al = Common.switchTo().alert();//to switch from webdriver to alert
	  al.getText();//To capture the alert message.
	  System.out.println(al.getText());
	  al.accept();//To click on the 'OK' button of the alert.
	  al.dismiss();//To click on the 'Cancel' button of the alert.
	  al.sendKeys("text");// To send some data to alert box.
  }
  
/*bootstrap alert*/
  @Test
  public void g() throws InterruptedException 
  {
		browserLaunch("Chrome", "https://www.icicibank.com");
		Common.findElement(By.xpath(".//*[@id='Loan']/div/h2")).click();
		String path = Common.findElement(By.xpath(".//*[@id='Loan_mod']/div[1]")).getCssValue("display");//used to get the css value
		if(Common.findElement(By.xpath(".//*[@id='Loan_mod']/div[1]"))!=null)
		{
			Common.findElement(By.xpath(".//*[@id='Loan_mod']/div[1]")).click();
		}	
  }
 
  
/*window popups uploading file from windows*/
  @Test
  public void h() throws InterruptedException, IOException 
  {
	//save with .html  /*<input id="1" type="file" name="ResumeUpload",=""*/
	//.exe file  /*ControlFocus,ControlSetText,ControlClick*/
		browserLaunch("Chrome", ""/*website name (.html)*/);
		Common.findElement(By.id("1")).click();
		Runtime.getRuntime().exec(""/*exe file name*/);//.exe is the static method,getruntime is the static method and can be called by classname that was present under the class called runtime		
  }
  

 /*Notifications*/
  @Test
  public void Notifications()
  {
	  ChromeOptions options = new ChromeOptions();//Create a instance of ChromeOptions class
	  options.addArguments("--disable-notifications");//Add chrome switch to disable notification – “–disable-notifications”
	  System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");//Set path for the chrome driver
	  Common=new ChromeDriver(options);//Pass ChromeOptions instance to ChromeDriver Constructor
	  Common.get("http://wordpressdemo.webkul.com/wordpress-latest-tweets/");//Give the navigation of the page in which we want to handle the notifications.
	  Common.manage().window().maximize();
  }
  
  @AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}

/*Alert is a small message box which displays on-screen notification to give the user some kind of information or ask for permission
  to perform certain kind of operation. It may be also used for warning purpose.'To handle we need to switch the control from 
  webdriver to alert(switchto is used to switching to frames,alerts,windows)
*/

//interrupts the execution of the application are called alerts,different kinds of alerts: java base alert,bootstrap alert, security alert, windows base alert and notifications

//java base alert: when user giving the wrong input in webelement at that time we get,once we handle only it goes to next step.java base alerts are not inspectable.
   /*1.simple alert:This simple alert displays some information or warning on the screen.*/
   /*2.Prompt Alert:This Prompt Alert asks some input from the user and selenium webdriver can enter the text using sendkeys(" input…. ").*/
   /*3.Confirmation Alert:This confirmation alert asks permission to do some type of operation.*/

//security alert:ontime password and captcha entries comes under security.we cant automate this.

//bootstrap alert:message with cross("x") symbol, web fields and actions,until we handle it will not close, backend will be masked,some will be there which will be for some seconds and some will be until we handel it and we can inspect.some times alerts will come and some times it will not come at that time we need to use one condition "when the locator exixts then click on that"
   /*1.bootstarp window:until we click it will not allow to click on any of the web element,contains some web elements like buttons,links etc.*/
   /*2.bootstrap alert: only cross mark will be there*/

//windows popups: selenium cannot inspect the web elements,because selenium will not support windows only supports for web.By using third party open source "AUTOIT" tool we can inspect the elements and handle the popups.
      //autoit installation : autoit download -> click on AutoIt Downloads - AutoIt -> on top bar click on AUTOIT tab and click on downloads -> scroll down and click on download autoit image ->open that file and install ->next ->select use native x64 tools by default ->next->finish
      //.au3 will be the extension while saving the autoit scripts.
      //In selenium we write scripts in eclips ide and for inspecting we use firebug and fire path, in windows for inspecting we use autoit and we write scripts in "SciTE"(downloading : click on autoit editor tab -> click on editor downloads ->go to current versions and click on "SciTE4AutoIt3.exe" ->install ->next ->i agree->finish)
      //open the physical folder where autoit istalled,to work with tool click on "Au3Info_x64.exe", by using finder tool icon we inspect the windows element, click on "SciTE" folder and click on "SciTE.exe" icon 
      //we have one api (help) documentation (c folder - program files - AutoIt3 - autoit.chm (question mark folder) - click on index tab)
      //controlfocus : if we want to enter any text first we need to do control focus in windows element - ControlFocus ("title","text",controlID), here in controlId we take the combination of class and instance from autoit inspector.
      //controlsettext : used to set the text on controlfocus - ControlSetText ("title","text",controlID,"new text"), new text is the path of the file which we need to upload
      //controlclick : after seting the text click(open) - ControlClick ("title","text",controlID)
      //we need to save the code with .au3
      //.Au3 file we can't use directly,we need to compile the file (right click on file - Compile Scriptv(x64) - one exe file is getting generated), we need to call that exe file in our code

//Notifications : by using Chrome or Firefox options we can handle
                 // we need to create one profile,with that profile object we can handle.
                 //example : profileobject.setPreference("dom.webnotifications.enabled",false);
                  


