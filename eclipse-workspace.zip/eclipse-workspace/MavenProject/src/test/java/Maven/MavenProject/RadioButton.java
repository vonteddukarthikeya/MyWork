package Maven.MavenProject;

import org.openqa.selenium.WebElement;

public class RadioButton {

	//Selecting radio button alternative way
			/*
			   List<WebElement> radio = driver.findElements(By.
			   xpath("//input[@name='optionsRadios' and @type='radio']")); for(int
			   i=0;i<radio.size();i++) { WebElement local_radio = radio.get(i); String value
			   = local_radio.getAttribute("value");
			   System.out.println("values for radio buttons are" +value);
			   if(value.equalsIgnoreCase("Company AAA")) { local_radio.click(); } }
			 */
	
	/*WebElement radio_Button = CustomerField;
	if (!radio_Button.isSelected()) {
		CustomerField.click();
		Thread.sleep(1000);
	}*/
	
	
}
