package Maven.MavenProject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelAPI 
{

	public FileInputStream fis=null;
	public FileOutputStream fos=null;
	public XSSFWorkbook workbook=null;
	public XSSFSheet sheet=null;
	public XSSFRow row=null;
	public XSSFCell cell=null;
	String xfilePath;
	
		
	
	public ExcelAPI(String xfilePath) throws Exception 
	{
		this.xfilePath=xfilePath;
		fis=new FileInputStream(xfilePath);
		workbook=new XSSFWorkbook(fis);
		fis.close();
	}


	public int getRowCount(String sheetName)
	{
		sheet= workbook.getSheet(sheetName);
		int rowCount=sheet.getLastRowNum()+1;
		return rowCount;
	}
	
	public int columnCount(String sheetName)
	{
		sheet=workbook.getSheet(sheetName);
		row=sheet.getRow(0);
		int colCount = row.getLastCellNum();
		return colCount;
	}
	
	
	
	//Reading cell data from Excel by using Column Number
	public String getCellData(String sheetName,int colNum,int rowNum)
	{
		try
		{
			sheet=workbook.getSheet(sheetName);
			row=sheet.getRow(rowNum);
			cell=row.getCell(colNum);
			
			if(cell.getCellTypeEnum()==CellType.STRING)
				return cell.getStringCellValue();
			else if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA)
			{
				String cellValue = String.valueOf(cell.getNumericCellValue());
				if(HSSFDateUtil.isCellDateFormatted(cell))
				{
					DateFormat dt=new SimpleDateFormat("dd/mm/yyyy");
					Date date=cell.getDateCellValue();
					cellValue=dt.format(date);	
				}
				return cellValue;
			}
			else if(cell.getCellTypeEnum()==CellType.BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
				
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "No matching value";
		}
	}
	
	
	//Reading cell data from Excel by using Column Name
	public String getCellData(String sheetName,String colName,int rowNum)
	{
		try
		{
			int colNum=-1;
			sheet=workbook.getSheet(sheetName);
			row=sheet.getRow(0);
			for(int i=0;i<row.getLastCellNum();i++)
			{
				if(row.getCell(i).getStringCellValue().trim().equals(colName))
					colNum=i;
			}
			
			row=sheet.getRow(rowNum);
			cell=row.getCell(colNum);
			
			if(cell.getCellTypeEnum()==CellType.STRING)
				return cell.getStringCellValue();
			else if(cell.getCellTypeEnum()==CellType.NUMERIC || cell.getCellTypeEnum()==CellType.FORMULA)
			{
				String cellValue = String.valueOf(cell.getNumericCellValue());
				if(HSSFDateUtil.isCellDateFormatted(cell))
				{
					DateFormat dt=new SimpleDateFormat("dd/mm/yyyy");
					Date date=cell.getDateCellValue();
					cellValue=dt.format(date);	
				}
				return cellValue;
			}
			else if(cell.getCellTypeEnum()==CellType.BLANK)
				return "";
			else
				return String.valueOf(cell.getBooleanCellValue());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "No matching value";
		}
		
		
	}
	
	
	//Writing cell data to Excel by using Column Number
	public boolean setCellData(String sheetName,int colNum,int rowNum,String value)
	{
		
		try
		{
			sheet=workbook.getSheet(sheetName);
			
			row=sheet.getRow(rowNum);
			//if(row==null)
				//row=sheet.createRow(rowNum);
			
			cell=row.getCell(colNum);
			//if(cell==null)
				//cell=row.createCell(colNum);
		
			
			cell.setCellValue(value);
			
			fos=new FileOutputStream(xfilePath);
			workbook.write(fos);
			fos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	
	//Writing cell data to Excel by using Column Name
	public boolean setCellData(String sheetName,String colName,int rowNum,String value)
	{
		
		try
		{
			int colNum=-1;
			sheet=workbook.getSheet(sheetName);
			
			row=sheet.getRow(rowNum);
			for(int i=0;i<row.getLastCellNum();i++)
			{
				if(row.getCell(i).getStringCellValue().trim().equals(colName));
				{
					colNum=i;
				}
			}
			row=sheet.getRow(rowNum-1);
			//if(row==null)
				//row=sheet.createRow(rowNum-1);
			
			cell=row.getCell(colNum);
			//if(cell==null)
				//cell=row.createCell(colNum);
			
			cell.setCellValue(value);
			
					
			fos=new FileOutputStream(xfilePath);
			workbook.write(fos);
			fos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}


}

/*
jars (dependencies):
jxl ---- .xls
apache poi  -------- poi,poi-ooxml,poi-ooxml-schemas (.xls & .xlsx)

java.io package (inputoutput) we are having various classes
FileInputStream - to read the data from excel
FileOutputStream - to write the data from excel
XSSFWorkbook - workbook 
XSSFSheet - inside workbook we have sheets
XSSFRow - inside sheets we have rows 
XSSFCell - in rows we have some cells
XSSFCellStyle - to apply some styles
XSSFColor - to apply some colors
XSSFChart - to get any charts
XSSFFont - to set any font
XSSFTable - to interact with table

read and write the data methods
getSheet("sheet Name") -- get sheet with the given name
getLastCellNum() -- get the indexof the last cell contained in the row plus one as index starts from zero
getRow(int) -- return the row
getCell(int) -- get the cell representing a given column
getStringCellValue() -- get the value of the cell as a string
getNumericCellValue() -- get the value of the cell as a numeric
getDateCellValue() -- get the value of the cell as date
getBooleanCellValue() -- get the value of the cell as boolean
createfont()
createCellStyle()

we can read and write the data by using column name and number, column name is the best way

when we are writing something into excel sheet we need to close the excel and write,but not required when reading from excel


*/
