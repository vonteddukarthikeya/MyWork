package Maven.MavenProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MultipleFramesHandling extends Browsers
{
	
  @BeforeMethod
  public void beforeMethod() 
  {

  }
  
  @Test
  public void f() 
  {
	  browserLaunch("Chrome", "http://www.angelfire.com/super/badwebs");
	  Common.switchTo().frame(1);//by using index
	  Common.switchTo().frame(Common.findElement(By.name("contents")));//by using locator
	  Common.findElement(By.linkText("I Hate Frames Page")).click();
  }
  
  
/*finding the element in which frame it is located by using logic*/ 
  @Test
  public void g()
  {
	  browserLaunch("Chrome", "http://www.angelfire.com/super/badwebs");
	  List<WebElement> myframes = Common.findElements(By.tagName("frame"));
	  System.out.println(myframes.size());
	
	  for(int i=0; i<myframes.size(); i++)
	  {
		  Common.switchTo().frame(i);
		  try
		  {
			  System.out.println("Frame index : "+i);
			  Common.findElement(By.xpath("html/body/p[6]/b/a/font")).click();
			  System.out.println("Element clicked using index -- "+ i);
	          break;
		  }
		  catch(Exception e)
		  {
			  System.out.println("Element not exist in frame .. "+i);
		  }
		  Common.switchTo().defaultContent();
	  }
  }
  

 /*switch from one frame to another frame*/
  @Test
  public void i()
  {
	  browserLaunch("Chrome", "http://www.angelfire.com/super/badwebs");
	  Common.switchTo().frame(1);//by using index
	  Common.switchTo().frame(Common.findElement(By.name("contents")));//by using locator
	  Common.findElement(By.linkText("I Hate Frames Page")).click();
	  
	  Common.switchTo().defaultContent();//switchout //defaultContent means it is giving control from frame to the webdriver
	  
	  Common.switchTo().frame(Common.findElement(By.name("main")));
	  Common.findElement(By.linkText("Enjoying the music?")).click();
  }
 
  
  @AfterMethod
  public void afterMethod() 
  {
	  Common.quit();
  }

}

//Some web elements will present inside the frames to work with that elements we need to work with frames (need to swith from web driver to frame) where we have to use the webdriver method called "swithTo" [syntax : Common.swithTo().frame()]

//switching the frame in three ways, once switching to the frame only we can interact with the web element
    //1.Frame Index  [Common.swithTo().frame(index);]
    //2.Frame Name   [Common.swithTo().frame(name/id);]
    //3.Frame Locator [Common.swithTo().frame(locator);]

//how to find the which is window or frame : 
   // window (on left top of console - we can see top window) 
   // frame  (on left top of console - we can see frame)

//in firefox just we can see the frame is present or not,we can't interact but in chrome we can interact and swith to locators
//when we are switching from one frame to another frame (different frames) we need to do switchOut (syntax : Common.switchTo().defaultContent();)