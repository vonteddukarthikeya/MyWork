package Maven.MavenProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class Annotations {
  @Test(priority=0)
  public void f() {
	  System.out.println("f");
  }
  
  @Test(priority=1,enabled=false)
  public void d() {
	  System.out.println("d");
  }
  
  @Test(priority=3)
  public void m() {
	  System.out.println("m");
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("beforeMethod");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("afterMethod");
  }


  @BeforeClass
  public void beforeClass() {
	  System.out.println("beforeClass");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("afterClass");
  }

  @BeforeTest
  public void beforeTest() {
	  System.out.println("beforeTest");
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("afterTest");
  }


  @BeforeSuite
  public void beforeSuite() {	
	  System.out.println("beforeSuite");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("afterSuite");
  }

}



//@test is created automatically once we create testng class
//first all before will be executed, next all test will be executed then after will be executed
//sequence of execution: beforeSuite,beforeTest,beforeClass,beforeMethod,test,afterMethod,afterClass,afterTest,afterSuite
//alphabetical order will be executed when you are written multiple tests, to run in given order we need to give "priority" ex: @Test(priority=0)
//dont want to execute one test from multiple tests, for that we need to add "enabled=false" ex:@Test(priority=1,enabled=false)
//testng build in html report - test-output (in leftside pannel under main project)-rightclick on index.html file-open with-web browser - click on first link under default suite (xml file will be there under every xml file class information will be there)
//testng build in html report - emailable-report.html-rightclick-open with-web browser
//to run all the testng classes(batch) we have to create our own xml 
//how to create xml files - right click on package-testng-convert to testng-change the testng.xml name, suitename and testname and click on finish
//to run all the class in multiple browsers (serial execution) - create multiple tests in xml file,we need to pass parameters ex:<parameter name="Browser" value="Chrome"></parameter>, passed parameters should be configure in respective classes before execution EX:@Parameters("Browser"/*name which is given in xml*/), pass string ex:public void startProcess(String browsertype)
//parallel execution - in xml file in suite section we need to give [parallel="tests"] ex:<suite name="Regression" parallel="tests">
//Grouping - in @Test and @BeforeMethod we need to add this in class files "groups= {"regression"}" ex:@Test(groups= {"regression","smoke"}) and in xml we need to configur like this below parameter tag "<groups><run><include name="smoke"></include></run>"
//dependencies - what should be executed next instead of executing in ascending order, we need to use "dependsonmethod" in test section ex:(dependsOnMethods= {"orange"}), if something got fails that method will fail and next methods will skip.


