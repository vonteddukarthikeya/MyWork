package Maven.MavenProject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SpecificGroupLinks extends Browsers
{
	int count=0;
		
		@BeforeMethod
		public void setUp()
		{
			
			browserLaunch("Chrome", "https://www.bing.com");
			
		}
		
		
		@Test
		public void linksHeader() throws InterruptedException 
		{
			WebElement header=Common.findElement(By.id("sc_hdu"));//finding the header element
			List<WebElement> links=header.findElements(By.tagName("a"));//under header all child elements
			
			System.out.println("Total Links present Header Page :" + links.size());
		
			for (int i=0;i<links.size();i++) 
			{
				if(!links.get(i).getText().isEmpty())
				{
					count++;
					if(links.get(i).getText().contentEquals("Maps"))//to get particular links
					{
						System.out.println(links.get(i).getText());
						links.get(i).click();
						Thread.sleep(4000);
						break;
					}
				}
			}
			
			System.out.println("Net Links visible are : "+count);	
		}
		
		@AfterMethod
		public void teatDown()
		{
			Common.close();
		}

}
