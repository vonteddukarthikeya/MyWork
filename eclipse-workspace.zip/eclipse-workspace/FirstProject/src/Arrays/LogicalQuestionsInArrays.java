package Arrays;

public class LogicalQuestionsInArrays 
{



private static int i;
private static int j;

//Finding Duplicate Elements 
	
	/*public static void main(String[] args) 
	{
		 String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};

		 for (int i = 0;i<a.length-1;i++)
	     {
	     for (int j =i+1;j<a.length;j++)
	     {
		 if (a[i].equals(a[j]))
		 {
		 System.out.println("duplicate element is :"+ a[j]);
		 }
	  }
    }
  }*/
	


	
	
//Bubble sort program for sorting in ascending Order
	
	/*public static void main(String[] args) {
	    int i,j;
	    int[] num={10,20,30,50,40,90,70};
	    
	    for (i = 0; i < ( num.length - 1 ); i++) {
	        for (j = 0; j < num.length- i - 1; j++) {
	          if (num[j] > num[j+1]) 
	          {
	           int temp = num[j];
	            num[j] = num[j+1];
	            num[j+1] = temp;
	          }
	        }
	      }
	    System.out.println("Sorted list of integers:");
	    
	    for (i = 0; i < num.length; i++) 
	      System.out.println(num[i]);
	  } 
	   

	
      public static void main(String[] args)
	    {
	        
	       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
	 
	        Arrays.sort(a);
	 
	        System.out.printf("Modified arr[] : %s",
	                          Arrays.toString(a));
	    }*/
	 

	
	
	
	
//Bubble sort program for sorting in descending Order
	
		/*public static void main(String[] args) {
		    int i,j;
		    int[] num={10,20,30,50,40,90,70};
		    
		    for (i = 0; i < ( num.length - 1 ); i++) {
		        for (j = 0; j < num.length- i - 1; j++) {
		          if (num[j] < num[j+1]) 
		          {
		           int temp = num[j];
		            num[j] = num[j+1];
		            num[j+1] = temp;
		          }
		        }
		      }
		    System.out.println("Sorted list of integers:");
		    
		    for (i = 0; i < num.length; i++) 
		      System.out.println(num[i]);
		  } 
	
	
	
	  public static void main(String[] args)
	    {
	    
	        Integer[] a = {13, 7, 6, 45, 21, 9, 2, 100};
	 
	        // Sorts arr[] in descending order
	        Arrays.sort(a, Collections.reverseOrder());
	 
	        System.out.printf("Modified arr[] : %s",
	                          Arrays.toString(a));
	    }*/
	  

	
	
	
	
//To find third largest number in array
	
	/*public static void main(String[] args) {

		int[] a= { 14, 46, 47, 86, 92, 52, 48, 36, 66, 85 };
		int largest = a[0];
		int secondLargest =a[0];
		int thirdLargest = a[0];	
		
	for (int i = 0; i < a.length; i++) 
	{
		System.out.print(a[i]+"\t");
		if (a[i]>largest)
		{
			secondLargest = largest;
			largest = a[i];
		}
		else if (a[i]>secondLargest)
		{
			thirdLargest=secondLargest;
			secondLargest=a[i];
		}
		else if (a[i]>thirdLargest)
		{
			
			thirdLargest=a[i];
		}
		}

		System.out.println("\nThird largest number is:" + thirdLargest);
 
	}*/
	

	
	/*public static void main(String[] args)
    {
        
       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
 
        Arrays.sort(a);
 
        System.out.println(Arrays.toString(a));
        System.out.println(a[3]);
    }*/
	
	
	
	
	
//To find third smallest number in array
	
		/*public static void main(String[] args) {

			int[] a= { 14, 46, 47, 86, 92, 52, 48, 36, 66, 85 };
			int smallest = a[0];
			int secondsmallest =a[0];
			int thirdsmallest= a[0];	
			
		for (int i = 0; i < a.length; i++) 
		{
			System.out.print(a[i]+"\t");
			if (a[i]<smallest)
			{
				secondsmallest = smallest;
				smallest = a[i];
			}
			else if (a[i]<secondsmallest)
			{
				thirdsmallest=secondsmallest;
				secondsmallest=a[i];
			}
			else if (a[i]<thirdsmallest)
			{
				
				thirdsmallest=a[i];
			}
			}

			System.out.println("\nThird smallest number is:" + thirdsmallest);
	 
		}*/
		
		
		
		
		/*public static void main(String[] args)
        {
        
        int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
 
        Arrays.sort(a);
 
        System.out.println(Arrays.toString(a));
        System.out.println(a[0]);
        }*/
	
	
	
	
	
//To find Array length	
	
	/*public static void main(String[] args)
    {
        
       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};

         Arrays.sort(a);
 
        System.out.println(Arrays.toString(a));
        System.out.println(a.length-1);
		
		//String[] str = {"karthik","dinesh","mallesh"};
		
		//System.out.println(str[0].length());
		
    }*/
	

	
	
	
//Array largest value
	
	/*public static void main(String[] args) {
	int[] a = { 100, 50, 20, 99 };
	int max =a[0];
	for(int i=0;i<a.length;i++)
	{
	if (a[i]>max)
	{
		max=a[i];
	}
	
	}

	System.out.println(max);
	}*/
	
	
	/*public static void main(String[] args)
	    {
	        
	       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
	 
	        Arrays.sort(a);
	 
	        System.out.println(Arrays.toString(a));
	        System.out.println(a[a.length-1]);
	    }*/

	
	
	
//Array smallest value
	
	/*public static void main(String[] args) {
	int[] a = { 100, 50, 20, 99 };
	int min =a[0];
	for(int i=0;i<a.length;i++)
	{
	if (a[i]<min)
	{
		min=a[i];
	}
	
	}

	System.out.println(min);
	}*/
	
	
	/*public static void main(String[] args)
	    {
	        
	       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
	 
	        Arrays.sort(a);
	 
	        System.out.println(Arrays.toString(a));
	        System.out.println(a[0]);
	    }*/
	

	
	
	
//Array mid value
	
	  /* public static void main(String[] args)
	    {
	        
	       int[] a = {13, 7, 6, 45, 21, 9, 101, 102};
	 
	        Arrays.sort(a);
	 
	        System.out.println(Arrays.toString(a));
	        System.out.println(a[(a.length-1)/2]);
	        System.out.println(a[a.length/2]);
	    }*/
	


	
	
//Most frequent element and how many times it occres
	
/*public static void main(String[] args) 
	{
	int[] a ={1,2,9,3,4,3,3,1,2,4,5,3,8,3,9,0,3,2}; 
	int maxFrequentNumber = 0;
	int maxOccurrenceCount = 0;

	int[] counts = new int[a.length];

	for (int i=0; i < a.length-1; i++) 
	{
	counts[a[i]]++;
	if (maxFrequentNumber < counts[a[i]]) 
	{
		maxOccurrenceCount = counts[a[i]];
		maxFrequentNumber = a[i];
	}
    }
	System.out.println("Frequent number is "+maxFrequentNumber);
	System.out.println("Number of Occurrence "+maxOccurrenceCount);
	}*/
	
	
	
/*public static void main(String[] args) 
	{
		 int[] a ={1,2,9,3,4,3,3,1,2,4,5,3,8,3,9,0,3,2,2,2,2,2,2,2};
		 int maxFrequentNumber = 0;

		 for (int i = 0;i<a.length-1;i++)
	     {
	     for (int j =i+1;j<a.length;j++)
	     {
		 if (a[i]==(a[j]))
		 {
			 maxFrequentNumber = a[i];
			 
		 }
	  }
    }
		 System.out.println("Frequent number is "+maxFrequentNumber);
  }*/


	

	
//count the occurrences of an element in an array
	
/*	 public static void main(String[] args)
	    {
	  
	        int[] a = { 1,4,5,2,3,5,1,6,4,7,1,3,6,8,2,5};
            Map<Integer, Integer> count = new HashMap<Integer, Integer>();      
	        for (int i = 0; i < a.length; i++)
	        {
	             int key = a[i];
	            if (count.containsKey(key))
	            {
	                int value = count.get(key);
	                value++;
	                count.put(key, value);
	            } 
	            else
	            {
	            	count.put(key, 1);
	            }
	        }
	        
	        for(Entry<Integer,Integer> val : count.entrySet())
	        {
	            System.out.println(val.getKey() + " occurs " + val.getValue() + " time(s)");
	        }
	    } */
	
	
	
	

	
//Convert array to arraylist
	
	
/*public static void main(String[] args) 
	{
    String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};
    ArrayList<String> convert= new ArrayList<String>(Arrays.asList(a));
    convert.add("Testing");
    convert.add("SAP");
    for (String str: convert)
    {
	System.out.println(str);
	}
  }*/
	
	
	/*public static void main(String[] args) 
	{
    String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};
    ArrayList<String> convert= new ArrayList<String>();
    Collections.addAll(convert,a);
    convert.add("Testing");
    convert.add("SAP");
    for (String str: convert)
    {
	System.out.println(str);
	}
  }
	
	
	/*public static void main(String[] args) 
	{
    String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};
    ArrayList<String> convert= new ArrayList<String>();
    for(int i=0; i<a.length; i++) 
    {
    	convert.add(a[i]);
    }
    for (String str: convert)
    {
	System.out.println(str);
	}
  }*/
	
	
	
	

//Missing number in an integer array
	
/*	public static void main(String[] args) 
	{
		int a[]= {1,2,4,6,10,15};
		 for (int i = 0; i <a.length - 1; i++) 
		 {
		        int next = a[i + 1];
		        int current = a[i];
		        if ((next - current) > 1) 
		        {
		            for (int b = 1; b < next - current; b++)
		                System.out.println("Missing Value : " + (current + b));
		        }
		    }
		
	}*/
		


	
	
//Array reverse	
	
  	/*public static void main(String[] args) 
	    {
		int a[]= {1,2,4,6,10,15};
		for (int i = 0; i < a.length / 2; i++) 
		{
	         int temp = a[i];
	         a[i] = a[a.length - 1 - i];
	         a[a.length - 1 - i] = temp;     
	    } 
		for (int i = 0; i < a.length; i++) 
		{
	         System.out.print(a[i]+" ");
        }	
	}*/
	
	
	
	/*public static void main(String[] args) 
	{
		StringBuffer buffer = new StringBuffer("ydderayekihtrak");
	    buffer.reverse();
	    System.out.println(buffer);	   
	}*/
	
	
	
	/*public static void main(String[] args) 
	{
	String a[]  = {"Chicken", "Soup", "Soul"};
	List<String> list = Arrays.asList(a);
	Collections.reverse(list);
	list.toArray(a);
	System.out.println(list);
	}*/
	
	
	


	
//Compare two arrays are equal	
	
	/*  public static void main (String[] args) 
	    {
	        int arr1[] = {1, 2, 3};
	        int arr2[] = {1, 2, 4};
	        int arr3[] = {1, 0, 3};
	        int arr4[] = {1, 2, 3};
	        System.out.println("Is array 1 equal to array 2?? " + Arrays.equals(arr1, arr2));
	        System.out.println("Is array 1 equal to array 3?? " + Arrays.equals(arr1, arr3));
	        System.out.println("Is array 1 equal to array 4?? " + Arrays.equals(arr1, arr4));     
	    }*/
	
	
	/* public static void main (String[] args) 
	    {
	        int arr1[] = {1, 2, 3};
	        int arr2[] = {2, 1, 4, 5};
	        int arr3[] = {2, 0, 3};
	        int arr4[] = {2, 1, 3};
	   if (Arrays.equals(arr1,arr2))
	   {
		   if (Arrays.equals(arr2,arr3))
		   {
			   if (Arrays.equals(arr3,arr4)) 
			   {
				   System.out.println("Equal");
			   }
		   }
	   }
	   else
	   {
		   System.out.println("Not Equal");
	   }
	        
	 }*/
	 
	 
	
//Copy elements from one array to another array

	/*public static void main(String[] args)
	{
		int a[] = {1, 8, 3};
		int b[] = new int[a.length];
		for(int i=0; i<a.length; i++)
		{
			b[i]=a[i];	
			
		}	
		for(int i=0; i<b.length; i++)
		{
            System.out.print(b[i]+" ");
		}		
	}*/
	

		/*public static void main(String[] args)
		{
			String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};
			String[] b = new String[a.length];
			b=a.clone();
			for(int i=0; i<b.length; i++)
			{
		        System.out.print(b[i]+" ");
			}		
		}*/
	
	
	
		/*public static void main(String[] args)
		{
			String[] a= {"Java", "JSP", "Servlets", "Java", "Struts", "JSP", "JDBC"};
			String[] b = new String[a.length];
			b=Arrays.copyOf(a, a.length);
			for(int i=0; i<b.length; i++)
			{
		        System.out.print(b[i]+" ");
			}		
		}*/
	



//sum,multiplication,substraction,division of array

		/*public static void main(String[] args)
		{
		 //int a[] = {19,21,29,37,64,43,58,12,5,99,86};
			int a[] = {2,5,5};
		 int sum=0;
		 int multiplication=1;
		 int substraction=50;
		 int division=50;
		 for (i = 0; i < a.length; i++)
		 {
			 sum=sum+a[i];
			 multiplication=multiplication*a[i];
			 substraction=substraction-a[i];
			 division=division/a[i];
		 }
		 System.out.println("Sum of array elements is:"+sum);
		 System.out.println("Sum of array elements is:"+multiplication);
		 System.out.println("Sum of array elements is:"+substraction);
		 System.out.println("Sum of array elements is:"+division);
		 }*/

		
		/*public static void main(String[] args)
		{
		 int a[] = {19,21,29,37,64,43,58,12,5,99,86};
		 int sum=Arrays.stream(a).sum();
		 System.out.println("Sum of array elements is:"+sum);
		 }*/
	
	
 



}
	
	
	
	
	
	
	
	
	
	
	
	
	


