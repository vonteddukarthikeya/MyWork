package Arrays;

import java.util.Scanner;

public class FirstArray 
{
	
static int[] a= {10,20,30,40};
static int sum=0;

static int[] b=new int[4];


	public static void main(String[] args) 
  {
//  first type
		
    for (int i=0; i<a.length; i++) 
	{
    System.out.println("a[" + i + "]=" + a[i]);
    sum=sum+a[i];
	}
    System.out.println("sum of array is :" + sum);
    
// second type
    
    b[0]=100; 
    b[1]=200; 
    b[2]=300; 
  
    
    for (int j=0; j<b.length; j++)
    {
    System.out.println(b[j]);
    }
    
//In runtime using scanner class objects
    
    Scanner sc=new Scanner(System.in/*reading data from console*/);//scanner class will be in java.util package, we can read the data in run time by using scanner class
    System.out.println("Enter Array Size: ");
    int size=sc.nextInt();
    int[] c=new int[size];
    System.out.println("Enter the array elements : ");
    for (int k=0; k<c.length; k++)
    {
    //c[k]= sc.nextInt();
    System.out.println(sc.nextInt());
    
	}
    
  }
  
}


//In java to take input in runtime we use scanner class, this will be in jave.util package
//To store multiple values in a single variable we go for arrays
//They are homogeneous, similar kind of data only we store in arrays variable. 
//To get the data we have to iterate, we should not use any variable to print.
//In arrays we get only length and hashcode, we will not get any other methods and we dont have any data structures.so people uses collections concept.just we can read we cant perform any data structure operations(adding, deleting etc)


/*one way of declaring the array variable

int[] a= {10,20,30,40};

*/

/*second way of declaring the array variable

int[] b=new int[4];

    b[0]=100; 
    b[1]=200; 
    b[2]=300;
    
*/