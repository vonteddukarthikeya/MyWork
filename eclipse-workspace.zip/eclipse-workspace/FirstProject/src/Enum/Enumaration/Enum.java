package Enum.Enumaration;

public class Enum {

}

/*Enum : If we want to represent a group named constants then we should go for enum.

example 1 : 
 enum Month 
 {
 JAN,FEB,MAR,....,DEC;
 }

example 2 : 
 enum Beer 
 {
 KF,KO,RC,FO;
 }

where ";" is optional

enum concept introduced in 1.5 version. the main objective of enum is to define our own data type (enumerated data type)

when compared to old languages enum, java enum is more powerful, because in java enum we can write methods, variables, constructors
 

 Internal Implementation of enum:
every enum internally implemented by using class concept
every enum constant is always public static final 
every enum constant represents an object of the type enum

example:
 enum BEER 
 {
 KF,KO,RC,FO;
 }
 
 class Beer
 {
 public static final Beer KF=new Beer();
 public static final Beer KO=new Beer();
 public static final Beer RC=new Beer();
 public static final Beer FO=new Beer();
 }

Enum concept simplifies the programmers code and reduces the length of line


Enum declaration : by using Keyword  "enum", by using enum name we access the enum constants, when 
                   trying to print enum constants we get output directly constant name
                   
                   
Enum should be declared enum either outside class (applicable modifiers are public,default and strictfp)
             or Inside the class(applicable modifiers are public,default,strictfp,private,protected,static)
             but not inside a method, if we declare we get compile time error

example:
 enum BEER 
 {
 KF,KO,RC,FO;
 }
 
 class tets
 {
  public static void main (string[] arg)
  {
   Beer b= Beer.KF; // we can access static variables directly with class name 
   System out println (b); // =>System out println (b.tostring()); if we are printing any enum internally tostring() gets implemented to return name of constant directly (KF)
  }
 } 

*/