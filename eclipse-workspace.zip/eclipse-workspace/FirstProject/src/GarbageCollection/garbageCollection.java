package GarbageCollection;

public class garbageCollection {

}


/*

History : In java we can create the object by giving a new keyword but we can't remove or delete an object once it is done, 
to do that we use garbage collection concept and introduced in java1.5 

Definition :The main purpose of garbage collector is to destroy the runtime unused memory automatically.here garbage means unused objects
 
Advantage : makes java memory efficient and automatically done(JVM)
jvm java virtual mission takes care of garbage collection we don't have to write any extra code for that
it runs inside the jvm, when we start jvm the garbage collector starts and just before the jvm end the garbage collector ends
 
Methodology used : Mark and Sweep, in this methodology it goes across entire heap memory and 
                   checks which memory address are being referenced and marked, and unmarked are sweep 

Methods : methods used in garbage collection
1.finilize() - it is invoked each time before object is garbage collected, 
               used for clean up processing part and method is defined in object class
2.gc() - it is used to invoked garbage collection and method is found in System and Runtime class
         system gc();
         
         
 Notes:
 Garbage means unwanted waste, collection means collecting. so garbage collection means unwanted waste collecting in general meaning
 
 In programming language "USELESS OBJECTS" are called garbage and those are collected by some person that person is garbage collector is known as garbage collection
 garbage collector is responsible to collect garbage collection, 

 Garbage collector will be running continuously back end for destruction of useless objects, so because of this memory problem will be very less, we control the out of memory exception
 
 

 
 
*/
