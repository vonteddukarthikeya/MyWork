package Collections;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListIteratorCursors 
{

	public static void main(String[] args)
	{
    LinkedList<String> a =new LinkedList<>();
    a.add("karthik");
    a.add("sahana");
    a.add("sasikala");
    a.add("mohana");
    a.add("sadasiva");
    a.add("narayanamma");
 
    System.out.println(a);
    ListIterator<String> lst = a.listIterator();
    while(lst.hasNext())
    {
    	String val = lst.next();
    	if(val.equals("mohana"))
    		lst.set("dinesh");
    	else
    		lst.remove();
    }
   System.out.println(a);
	}

}
