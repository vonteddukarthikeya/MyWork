package Collections;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapsCollections 
{

	public static void main(String[] args) 
	{

      Map<Integer/*key*/,Integer/*value*/> a=new HashMap<Integer,Integer>();//here we can give any entity combinations 
      a.put(1, 100);
      a.put(20, 100);
      a.put(30, 200);
      a.put(4, 100);
      a.put(30, 100);
      a.put(30, 300);
      a.put(null, 100);
      
      LinkedHashMap<Integer,String> b=new LinkedHashMap<Integer,String>();
      b.put(1, "karthik");
      b.put(1, "mohan");
      b.put(20, "karthik");
      b.put(30, "karthik");
      b.put(4, "karthik");
      b.put(1, "mohan");
      b.put(1, "dinesh");
      b.put(null, "karthik");
      
      TreeMap<String,Integer> c=new TreeMap<String,Integer>();
      c.put("bcdea", 3);
      c.put("cabde", 2);
      c.put("ebacd", 1);
      c.put("dcbae", 4);
      c.put("abcde", 5);
      c.put("dcbae", 4);
      
      
      System.out.println(a.get(1));
      System.out.println(a.get(20));
      System.out.println(a.get(4));
      System.out.println(a.get(30));
      System.out.println(a.get(null));
      
      System.out.println(b.get(1));
      System.out.println(b.get(20));
      System.out.println(b.get(4));
      System.out.println(b.get(30));
      System.out.println(b.get(1));
      
      System.out.println(c);
      
         
	}

}

//Map is an sub interface and have some implemented classes (Hash Map,Linked HashMap and Tree Map)
//Map - insertion order is not preserved(same order will not print), here everything will store in key value pair, duplicates are not allowed,{key=value,key=value} in this form data is stored in map
//Hash Map - insertion order is not preserved(same order will not print), here everything will store in key value pair, duplicates are not allowed
//Linked HashMap -  insertion order is preserved(same order need to print), here everything will store in key value pair, duplicates are not allowed
//Tree Map - Stores the data in ascending order, here everything will store in key value pair, duplicates are not allowed
/* For practice site ----  "java2novice"  */
