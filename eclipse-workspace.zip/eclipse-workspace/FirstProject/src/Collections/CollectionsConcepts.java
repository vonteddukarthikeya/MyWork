package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class CollectionsConcepts {

	public static void main(String[] args) 
	{

    ArrayList a=new ArrayList();//If we are not giving any datatype, by default it takes "object e", so we can store any type of data (int,float,string etc..)
    a.add(10);
    a.add("karthikeya");
    a.add(12.34f);
    a.add(10);
    a.add(20);
    
    ArrayList<Integer> b=new ArrayList<>();//Here we are taking "Integer" as entity,s only integer related data will be stored
    b.add(10);
    b.add(10);
    b.add(20);
    
    List<Object> c=new ArrayList<>();//Anotherway of defining List,here parent class holds child class 
    c.add(10);
    c.add("karthikeya");
    c.add(12.34f);
    c.add(10);
    c.add(20);
    
    HashSet<String> d=new HashSet<>();
    d.add("karthik");
    d.add("sahana");
    d.add("sasikala");
    d.add("mohana");
    d.add("sadasiva");
    d.add("narayanamma");
    d.add("karthik");
    
    Set<Float> e=new LinkedHashSet<>();
    e.add(12.56f);
    e.add(24.56f);
    e.add(12.56f);
    e.add(36.56f);
    e.add(48.56f);
    
    
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(d);
    System.out.println(e);
    
	}

}


//Group of elements or entities is called collection, hetrogenious data can store
//array is a variable but collections is a interface which is present under java.util package and contains data structure methods
//size can be increased or decreased dynamically where as in arrays length is fixed
//Collection interfaces having sub interfaces (List,set,Map,Queue), sub interfaces list and set contains implemented classes (ArrayList,LinkedList,Vector,Stack,Hashset,StoredSet,LinkedHashst,Navigableset,Treeset,Hash map, linked hashmap, tree map,PriorityQueue,BlockingQ)
//In implemented classes all the abstract methods got defined
//Legacy classes and non legacy classes, java verson above "1.0" above are classed nonlegacy and below '1.0' are legacy classes

//List -arraylist -duplicates are allowed and insertion order is preserved(same order need to print) 
//List -linked list -duplicates are allowed and insertion order is preserved(same order need to print)
// difference between array list and linked list : 
     //retrieval is best and insertion, deletion is worst in arraylist, arraylist implements random access interface
     //insertion, deletion is best and retrieval is worst in linkedlist, linkedlist will not implements random access interface
    //example: employee name 

//Here "object e" means we can add any type of data (int,float,string etc..)

//Set- HashSet -duplicates are not allowed and insertion order is not preserved(same order will not print)
//Set - LinkedHashSet -duplicates are not allowed and insertion order is preserved(same order will print) 
//Set - TreeSet -Stores the data in ascending order,duplicates are not allowed
   //example: phone numbers, employee id


//Map is an sub interface and have some implemented classes (Hash Map,Linked HashMap and Tree Map)
//Map - insertion order is not preserved(same order will not print), here everything will store in key value pair, we may have duplicate values but no duplicate keys
//Hash Map - insertion order is not preserved(same order will not print), here everything will store in key value pair, duplicates are not allowed
//Linked HashMap -  insertion order is preserved(same order need to print), here everything will store in key value pair, duplicates are not allowed
//Tree Map - Stores the data in ascending order, here everything will store in key value pair, duplicates are not allowed
       //example: key:id,value:names
/* For practice site ----  "java2novice"  */


//Queue : The Queue is used to insert elements at the end of the queue and removes from the beginning of the queue. It follows FIFO concept. The Java Queue supports all methods of Collection interface including insertion, deletion etc.

//Methods in collection : add,addall,clear,contains,equals,hashcode,isempty,iterator,remove,removeall,size,toarray,set,get,firstset,lastset,firstget,lastget