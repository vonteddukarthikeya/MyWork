package Collections;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorCursors 
{

	public static void main(String[] args) 
	{
		ArrayList<Integer> a=new ArrayList<>();
		for(int i = 0;i<=10;i++)
		{
			a.add(i);
		}
		System.out.println(a);
		Iterator<Integer> itr = a.iterator();
		while(itr.hasNext())
		{
			Integer value = itr.next();
			if(value%2==0)
        		System.out.println(value);
			else
				itr.remove();
		}
		
       System.out.println(a);
	}

}
