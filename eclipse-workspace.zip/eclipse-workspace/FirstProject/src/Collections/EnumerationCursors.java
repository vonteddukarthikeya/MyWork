package Collections;

import java.util.Enumeration;
import java.util.Vector;

public class EnumerationCursors 
{

	public static void main(String[] args) 
	{
		Vector<Integer> a=new Vector<>();
		for(int i=1;i<=10;i++)
		{
			a.add(i);
		}
        System.out.println(a);
        Enumeration<Integer> values = a.elements(); //by using "elements()" method we can get enumeration object
        while(values.hasMoreElements())
        {
        	Integer val = values.nextElement();
        	if(val%2==0)
        		System.out.println(val);
        }
        System.out.println(a);
	}

}



//Cursors are used to iterate the elements of collection objects
//3 types of cursors (Enumeration,Iterator,ListIterator)
//For legacy(Vector[1.0 version],Stack[1.0 version]) classes if we want to do some transactions there we have to use iteratations (Enumeration we suppose to use for the legacy classes)
//Enumeration - When using Enumeration just we can read the data, we can't remove,add and replace the element
                //by using "elements()" method we can get enumeration object
                //methods : hasmoreelements(); , nextelement();
                //example : Maps
//Iterator - When using Iterator we can read,remove the data, we can't move in reverse direction we only moves in forward direction, we can't add or replace the elements
               //by using "iterator()"method we can get iterator object
               //methods : hasnext(); , next(); , remove();
               //example : List, Set
//ListIterator - When using Iterator we can read,remove,add,replace,forward and move reverse direction
               //by using "listIterator()" method we can get listIterator object
               //methods : hasnext(); , next(); , equals(); , set(); , remove();
               //example : List, Set
