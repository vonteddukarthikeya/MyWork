package MemoryManagement;

public class memorymanagement {

}

/*
JDK : java development kit
To develop and run the java applications the required environment is jdk
Installed in Developers machine because developers will develop and run the application
JDK = JRE + Development Tools
JDK Tools : java runtime environment,Interpreter,Compiler,Archiver, API Document generator, Debugger etc.
JDK does : take source file -> save with source file.java ->converted into set of byte code.class
JDK packages : Java Enterprise Edition (Java EE), Java Standard Edition (Java SE), and Java Mobile Edition (Java ME)
*/


/*
JRE : java runtime environment
Just to run the java applications the required environment is jre and JVM is the responsible to run the program in JRE
Installed in client machine because client will not develop the application just he run the application
JRE = JVM + Library Classes
JRE contains libraries, property settings, and resource files used by the Java runtime environment
examples: rt.jar -the bootstrap classes, charsets.jar -character conversion classes, resources.jar
In Library we have all .jar files
*/



/*
JVM : java virtual mission
To run over java program line by line jvm is the responsible, 
Thats why jvm is an interpreter, if some where in middle exception rises from there it stops executing the program
JVM is the key, because it is embodied into JDK and JRE
The most common interaction with a running JVM is to check the memory usage in the heap and stack.
The JVM manages memory through a process called garbage collection, which continuously identifies and eliminates unused memory in Java programs. Garbage collection happens inside a running JVM.
*/



/*
 Memory Management:
 Java memory is divided into two parts 
 1.Heap memory
 2.Stack memory
  
--->Heap Memory : Heap memory is only for storing class objects, all JRE classes and GC runs on heap memory only
                  Heap memory is further divided into two types
     1.Young generation : when ever we are creating any class object, all the class objects will be stored first time inside the young generation memory space.
           young generation further divided into three major parts
           1.Edan memory :when we create new memory always stores here, when Edan memory got filled completely garbage collection mechanism will be called and that is called minor GC
             GC means garbage collector, what exactly it does is it will shift all the surviver objects in s0 and s1
             What ever objects are important when Edan memory is filled Minor GC will move to Survior memeory 
             when blank or unused objects are available, those objects are deleted by Minor GC.
           2.Survior memory (s0)
           3.Survior memory (s1)
     2.Old generation : When s0 and s1 memory gets filled at that time what exactly java will do is shifts all the objects into Old generation.
                        when old generation gets filled completely then java calls Major GC. Major GC takes longer time and degrades the performance and gets timeout errors
     
Memory Pool : It is a part of heap memory and stores immutable objects (string class,string pools)
              It is defined at runtime JVM memory managers
                      
Permanent generation : the entire Meta data of classes, Methods will be stored here	
                       It is not the part of the heap memory it is separately 
                       It will be generated at the runtime       
                       In permanent generation we have Method Area  
Method Area : here we stores complete class structure, all static variables and constant variables
Runtime constant pool : It is a part of method area, used to store all the static variables and the constant variables
                       
                       
--->Stack Memory : Used for execution of threads 
                   contains method specific values
                   local variables (int i=0) will be stored
                   object references which are referring some objects on heap memory
   Stack memory size is very less compared to heap memory size

Interview Questions:
Object will be stored inside heap memory but reference will be in stack memory and it will refer from stack memory to heap memory and stores the value on LFO concept
example : Test t1=new Test();

*/






