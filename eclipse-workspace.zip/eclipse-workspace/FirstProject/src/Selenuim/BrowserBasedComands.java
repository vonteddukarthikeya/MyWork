package Selenuim;

public class BrowserBasedComands extends Browsers 
{

	public static void main(String[] args) throws InterruptedException 
	{
	
		browserLaunch("Chrome", "https://www.flipkart.com");
		
		Common.manage().window().maximize();//maximize the window
		
		Common.manage().deleteAllCookies();//delete all cookies
		
		String title = Common.getTitle();//get the title
		System.out.println(title);
		
		String url = Common.getCurrentUrl();//get the url
		System.out.println(url);
		
		Common.navigate().back();//navigate to back page
		
		Thread.sleep(4000);//synchronisation between two events (wait for sum time)
		
		Common.navigate().forward();//navigate to forward page
		
		Common.navigate().refresh();//refresh the page
		
		Common.close();//used to close only active window
		
		Common.quit();//used to close more than one widows
		
		
	}

}
