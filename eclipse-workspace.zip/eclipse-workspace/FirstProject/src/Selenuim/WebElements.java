package Selenuim;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class WebElements extends Browsers 
{

	public static void main(String[] args) throws InterruptedException 
	{

		browserLaunch("Chrome", "https://www.amazon.in");
		
	    Common.manage().window().maximize();
		
	    WebElement val = Common.findElement(By.id("twotabsearchtextbox"));
        val.sendKeys("Harry Potter");//sendkeys:if we want to enter any text in textbox we use sendkeys method
        val.clear();
     
        
        Common.findElement(By.name("field-keywords")).sendKeys("Samsung");
        Common.findElement(By.name("field-keywords")).clear();
    
       
        Common.findElement(By.className("nav-input")).sendKeys("Mobile Phones");
      
        
        Common.findElement(By.xpath(".//*[@id=\"twotabsearchtextbox\"]")).clear();
       
        
        Common.findElement(By.cssSelector("#twotabsearchtextbox")).sendKeys("Laptops");
        Common.navigate().refresh();
     
        
        Common.findElement(By.linkText("Customer Service")).click();
        Common.navigate().back();
      
        
        Common.findElement(By.partialLinkText("Deals")).click();
        Common.navigate().refresh();
        
        List<WebElement> ele = Common.findElements(By.tagName("a"));
        System.out.println(ele.size());
        for (int i=1; i<ele.size(); i++)
        {
        	System.out.println(ele.get(i).getText());
        }
	}

}

/*To find the web elements in Firefox browser we need to add Firebug and Firepath, firebug is addon to firefox browser and firepath is addon to firepath
  FireBug is used to identify the properties of elements in web application and 
  FirePath is used to identify the xpath and css of elements in the web application
  Click "Alt+t" - tools menu - Add ons - extensions - search in firebug and firepath - click respetive links - click on add to firefox - install
*/

//8 Locators - id(), name(), className(), linkText()-links which are static, partialLinkText()-links which are changing dynamically, xpath(), cssSelector(), tagName()-if we want to work with more than one elements we go for tagname

//if we are working with any single webelement we use the method findelement return type will be webelement,when we want to work more than one webelements we use the method findelements return type will be list<webelement>

/*Two types of Xpaths (Absolute and Relative Xpath),preffered one is relative xpath
  Absolute Xpath always starts with "html" DOM tree, it takes from root to end completly,low performance
  Relative Xpath always starts with "//", root can be anything takes always inspected element,high performance
*/

//linktext: when link names are not chaning we go with linktext(static)

//partiallinktext: when link names are changing we go with partiallinktext(dynamic)

//Different types of web elements : Text box, Button, Drop down, Hyperlink, Check box, Radio button