package Selenuim;

public class Xpaths 
{

	public static void main(String[] args) 
	{
	

	}

}


//2 types of xpaths (absolute[starts with html dom tree],relative[starts with //])

/*using single,multiple and index attributes //tagname[@attribute1='value1']  
                                             (//tagname[@attribute1='value1'])[1]   
                                             //tagname[@attribute1='value1'][@attribute2='value2']
*/

//parent child relation  //parenttagname[@parentattributename='value']/childtagname[@childattributename='value']

//http://www.angelfire.com/super/badwebs/     {for checking purpose only}

/*xpath functions  
last()  {instead of index we can use last} 
        //tagname[@attribute='value'][last()]  
        //tagname[@attribute='value'][last()-1]
      
position()  {instead of index we can use position}
           //tagname[@attribute='value'][position()=1]
            
text()  {To locate links & labels}
        //tagname[text()='text value'] 
         
starts-with() {equals with partiallink text}
              //tagname[starts-with(text(),'starting value')]   -- starting letter with static and ending letter with dynamic then we go with starts-with   
               
contains()  {equals with partiallink text}
            //tagname[contains(@attributename,'partial value')]    
            //tagname[contains(text(),'partial value')]  -- link name is changing dynamically in any of the position then we do with contains
*/

/*xpath operators
1.AND
2.OR
*/
