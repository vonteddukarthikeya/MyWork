package Selenuim;

public class Css 
{

	public static void main(String[] args) 
	{


	}

}


/*Addvantages of css over xpath 
1.css will not change from browser to browser as xpath will change.  
2.css is native browser and xpath is not  
3.css is having high performance in identifying the web elements than xpath
*/

//we can write the css selector with 8 methods (tagname,id(#),classname(.),attribute,contains,starts-with,ends-with,using siblings)

//for css selector syntax we will not give "//" and "@"

//multiple attributes to find the elements --- tagname[attribute='value1'][attribute='value']

/*when we use contains  method to identify the element,need to use "*"      tagname[attribute*='partial value'] 
  when we use starts-with method to identify the element,need to use "^"    tagname[attribute^='starting value']
  when we use ends-with method to identify the element,need to use "$"      tagname[attribute$='ending value']
*/
		  