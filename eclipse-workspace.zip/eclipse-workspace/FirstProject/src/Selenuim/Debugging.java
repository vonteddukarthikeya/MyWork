package Selenuim;

public class Debugging {

}


/*
To notice that what happening in the execution flow we place debuggers, we can say it is a helper 
  where we can trace out the issue where exactly we are getting
We need to place break points before debugging, if we double click on the line break points gets inserted or use toggle breakpoint

Debug mode : Run - Debug As

Select some window in debug mode : Windows - Show View - (Breakpoints,Console,Debug,Error Log,Expressions,Outline,Variables,Expressions)

Step Into(F5) : Going inside the function, it is a function call it has to go inside the function and debug line by line

Step Over(F6) : In one shot to execute the function definition and control has to come to the next level
*/