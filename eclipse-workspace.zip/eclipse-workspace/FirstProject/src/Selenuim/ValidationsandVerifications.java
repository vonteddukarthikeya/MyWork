package Selenuim;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import junit.framework.Assert;

public class ValidationsandVerifications extends Browsers
{

	public static void main(String[] args) 
	{
		
		browserLaunch("Chrome", "https://qa1.insightsc3m.com");	
		//Validation
		String actualvalue = Common.findElement(By.xpath("//a[text()='Forgot Password?']")).getAttribute("innerHTML");
		String expectedvalue ="Forgot password?";
		//Verification
		if(actualvalue.equalsIgnoreCase(expectedvalue))
		{
			System.out.println("Both are equal");
		}
		else
		{
			System.out.println("Both are not equal");
		}
		
		
		
		/*browserLaunch("Chrome", "https://www.amazon.in");	
		WebElement keys = Common.findElement(By.id("twotabsearchtextbox"));
		keys.sendKeys("Harry Potter");
		String val = keys.getAttribute("value");
		System.out.println("actual value is:" +val);*/
	}

}


//actual coming from application and expected from client expected results
//gettext or getattribute are used to get something from the application
//gettext always capture which are visible in the application like linknames and labelnames
//getattribute capture webelement inner properties like id,tagname,linkname,classname

/*
Assertions verify that the state of the application is same to what we are expecting. Selenium Assertions can be of three types: 
�assert�, �verify�, and � waitFor�. 
When an �assert� fails, the test is aborted. 
When a �verify� fails, the test will continue execution, logging the failure.
A �waitFor� command waits for some condition to become true. They will fail and halt the test if the condition does not become true within the current timeout setting. Perhaps, they will succeed immediately if the condition is already true.
When, we talk about the assertions used in WebDriver using TestNg framework, we have two types of assertions; hard assertion and soft assertion.
hard assertion : A hard assert throw AssertException immediately after a test fails and the test is marked as failed.
Assert.assertEquals(actual,expected);
Assert.assertNotEquals(actual,expected,Message);
Assert.assertTrue(condition);
Assert.assertFalse(condition);
Assert.assertNull(object);
Assert.assertNotNull(object);
soft assertion : So, to overcome this drawback of hard assertion we can use soft assertions in testNg.
To use a soft assertion in testNg, we have to include it�s corresponding class (as SoftAssert()) in the script. This class prevents the execution to throw any exception (of assertion). Also, the most important context is, now the failed assertions will be reported in the testNg report and not making the test to abort anywhere.
Let�s see an example of soft assertion in testNg. Also, try to look at the difference between the two assertion and which assert should be used when.
SoftAssert softAssert = new SoftAssert();
*/