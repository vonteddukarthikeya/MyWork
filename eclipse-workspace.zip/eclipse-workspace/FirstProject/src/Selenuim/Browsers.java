package Selenuim;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Browsers 
{

	public static WebDriver/*interface*/ Common;//static giving means without object we can use
	
	public static void browserLaunch(String browser,String url)
	{
		if(browser.equalsIgnoreCase("Chrome"))
		{
			System/*class name*/.setProperty/*static methos*/("webdriver.chrome.driver"/*key:standard key word and need to be in small letters only*/, "D:\\Selenium\\chromedriver.exe"/*value:should be the physical path of the drivers*/);//before launch the browser we need to setup the driver path from respective browsers //system.set method ,setproperty is a static method and called by class name 
			Common=new ChromeDriver();/*ChromeDriver is a class to launch the chrome browser*/
			//Commom.get("https://www.amazon.in");//get method is used to launch the application browser
		}
		else if(browser.equalsIgnoreCase("Edge"))
		{
			System.setProperty("webdriver.edge.driver", "D:\\Selenium\\MicrosoftWebDriver.exe");
			Common=new EdgeDriver();
			//Commom.get("https://www.flipkart.com");
		}
		else if(browser.equalsIgnoreCase("IE"))
		{
		    System.setProperty("webdriver.ie.driver", "D:\\Selenium\\IEDriverServer.exe");
		    Common=new InternetExplorerDriver();
			//Commom.get("https://www.amazon.in");
		}
		else if(browser.equalsIgnoreCase("Firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "D:\\Selenium\\geckodriver.exe");
			Common=new FirefoxDriver();
			//Commom.get("https://www.flipkart.com");
		}
		Common.get(url);
	}
	

}

