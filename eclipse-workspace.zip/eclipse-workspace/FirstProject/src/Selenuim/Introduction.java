package Selenuim;


public class Introduction extends Browsers
{
  
	public static void main(String[] args) 
	{
		browserLaunch("Chrome", "https://www.amazon.in");		
	}

}

/*
//What is selenium - selenium is an WebDriver Interface

//What is the default browser for selenium - Firefox

//Is selenium is a software - No, it is API (Application Programing Interface) JAR file where we need to download 
    and configur to current project
 

//download Dependent jar files to work with selenium from "seleniumhq.org" site

//Download - Selenium standalone server - download 3.13.0 latest version and configur to current project, 
             suppose to download older version we need to click on Previous Releases
 
//Here we have three webdriver versions, webdriver 1 -Selenuim Remote Control (RC), webdriver 2 & 3 - Selenium WebDriver
 
//Download - Language Bindings - Java, what ever standalone server version we downloaded the same language verson 
            should be downloaded, suppose if we want to download the old verson we need to click on Previous releases
 
//Download - Browser Drivers,all drivers are not developed by the selenium developed by third party comunity,only IE drivers are developed by the selenium community
//Download - Language Bindings - Javadoc - org.openqa.selenium (package) - WebDriver (Interface) - Implemented Class (ChromeDriver, EdgeDriver, EventFiringWebDriver, FirefoxDriver, InternetExplorerDriver, OperaDriver, RemoteWebDriver, SafariDriver) - Abstract Methods 
//we need to configur classes - Right click on project - build path - configure build path - Click on Libraries - Add external JARS - specify the downloaded standalone server path - Apply and close
//Projects in selenium: 1.selenium IDE,2.RC , 3.webdriver, 4.grid
//Selenium IDE -It is just record and playback tool,no need of writing the automation scripts.record once and play many times.the drawback is only in firefox browser the application can be recorded and executes and IDE is addon.not support cross browser and cross platform,manually we need to open the firefox browser to record and playback.we cant execute with different sets of data the same sets of data only we execute,all web elements are not identified
//Selenium Remote Control -Crossbrowser and cross platform and various testing frameworks and languages are supported,written scripts are run locally or in other missions which are intenally connected in a lan missions only but in cloud[here we need to puchange multiple missions,office space,licences,pay tax for the each computer]
//Selenium Grid -Selenium Grid takes RC and webdriver to another level by running tests on many servers at the same time(scale and distribute scripts across many environments),cuting down the time it takes to test multiple browsers or operating systems
//Selenium Webdriver -Crossbrowser and cross platform and various testing frameworks and languages are supported,written scripts are run locally and other remote missions (cloud)
*/