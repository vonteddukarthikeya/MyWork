package ExceptionHandling;

import java.util.Scanner;

public class ExceptionThrow extends Exception {

	static int sal;
	
	public ExceptionThrow(String msg1) 
	{
		super(msg1);
	}

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		while(true)
		{ 
			
		
		 try 
		 {
			 System.out.println("Enter the Alphanumaric :");
				
				String no=sc.nextLine();
		if(no.length()!=10)
			
		{
			throw new ExceptionThrow("Number should be 10 digits");
		}
		else
		{
			System.out.println("Entered Number is :"+no);
		
		}
		
		System.out.println("Enter salary :");
		sal=sc.nextInt();
		if(sal<5000)
		{
			throw new ExceptionThrow("Salary should be greater than 5000");
		}
		else
		{
			System.out.println("Entered Salary is :"+sal);
			break;
		}
		} 
		 
		 catch (ExceptionThrow e) // exception is the parent class for athmeticexception
		 { 

			System.out.println(e.getMessage());
		
		 
		}
	}

   }
}

//here in throw object creation is our responsibility for custom messages for predefined messages jvm is the responsibily