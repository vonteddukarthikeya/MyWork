package ExceptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException; // ctrl+shift+o
import java.io.IOException;

public class ExceptionThrows 
{
static FileInputStream fis;
	public static void m1() throws IOException 
	{
		try {
			 fis=new FileInputStream("D:\\Users\\kvontedd\\Desktop\\SupplierDetails_2017-05-31T043958.xlsx");
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		finally
		{
			fis.close();
			System.out.println("file closed");
		}
	}
	
	public static void main(String[] args) throws IOException  
	{
		m1();
	}
	
	
/*----- Throws ------
	public static void main(String[] args) throws Exception 
	{
		FileInputStream fis=new FileInputStream("c://addbc.txt"); //java.io - FileInputStream (if we want to read any data from file we use this)

	} */

}


//checked exceptions - occures during compile time, asking for to entitled with try chatch or throws keyword
//unchecked exceptions - occures during runtime
//calling function - bellow m1(); is calling function
//called function - above m1() is called function
//in Called function if we are entitled with throws key word at that time in calling function also we need to use throws or try catch key word
//in Called function if we are entitled with try catch at that time in calling function we need not use throws or try catch key word