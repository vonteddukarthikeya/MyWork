package ExceptionHandling;

import java.util.Scanner;

public class ExceptionTryCatch 
{
 
public static void main(String[] args)
{
	 int d;
	 int n;
Scanner sc=new Scanner(System.in); // java.util package the scanner class will be there

while(true)
{ 
	System.out.println("Enter Numarator value :");
	n=sc.nextInt();
	System.out.println("Enter Denominator value :");
	d=sc.nextInt();
 try 
 {
	int result =n/d;
	 System.out.println(result);
	 break;
} 
 
 catch (Exception e) // exception is the parent class for arthmeticexception
 { 

	e.printStackTrace(); //we get both error message and line when we use printstacktrace
	System.out.println(e); // just gives error message not error line in console if we use sysout
	System.out.println("Denominator value should be greater than 0"); //customised message
 }
 finally 
 {
  System.out.println("True");
 }
 
}
}
}


//Compile time error: The errors raised during compilation time are called as compile time errors and these are mainly syntax and spelling mistakes.

//Error which comes during run time are called exceptions or runtime errors and mainly logical mistakes in code

//Object is Super class,Throwable is the parent class in java.lang package, under throwable there are two subclass (exception and error)

//exception -- runtime exceptions (AnnotationTypeMismatch,Arithmetic,ArrayStore,DataBinding,DateTime,FileSystemAlreadyExixts,FileSystemNotFound,IndexOutOfBounds,NegativeArraySize,NoSuchElement,NullPointer,Security,System,WrongMethodType)

/*Exception :Exception is an event raised while program execution and which disturbs normal execution flow we are calling as exception.
             The process of what we follow to handling the exception we are calling as exception handling process.
*/

//try- whatever the code we are writing that should be kept in try block

//catch - if any exception comes,catch block will be handling that exception

//if we are knowing direct the exception class like (arthmetic/array/ etc..) we can give otherwise we can give the parent class also ("Exception")

//To read the values in the console output instead of hardcoring the values we use "scanner" class ---- Scanner sc=new Scanner(System.in);

/*throw - we can throw our own exceptions for the specific project (we can throw exceptions manually), object creation is our responsibility for custom messages for predefined messages jvm is the responsibily
          Example : InsufficientFundsException
          throw new ExceptionThrow("Number should be 10 digits");
*/

//throws - Just to get exception message, we dont want to handle the exception at that time we go with this

//finally - any code which is written in finally block must be executed once wheather an exception is thrown or not (used for killing the process)

/*checked exceptions - occures during compile time, asking for to entitled with try chatch or throws keyword
  unchecked exceptions - occures during runtime
  calling function - bellow m1(); is calling function
  called function - above m1() is called function
  in Called function if we are entitled with throws key word at that time in calling function also we need to use throws or try catch key word
  in Called function if we are entitled with try catch at that time in calling function we need not use throws or try catch key word
*/
