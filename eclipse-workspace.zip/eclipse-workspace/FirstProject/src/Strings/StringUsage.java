package Strings;

public class StringUsage 
{
String str2;
	public static void main(String[] args) 
	{
		
	   StringUsage stgu=new StringUsage();// varible declares out side with no data
	   System.out.println(stgu.str2);
		
	   String str="karthikeya"; // Literal Declaration
	   System.out.println(str);
	   System.out.println(str.hashCode());
	   
	   String str1=new String("Reddy"); // Class object
	   System.out.println(str1);
	   System.out.println(str1.hashCode());
	   
	   String str3;
	   str3=str+str1;
	   System.out.println(str3);
	   System.out.println(str3.hashCode());
   
	}

}



// Group of characters is called as a string, represents in double couts("")
// string is class not data types, using "String" class only we represents strings
// two ways we can declare the string one is literal and other one is creating the class object for class because string is a class
//Literal way - String name="karthikeya" (called assignment operator)
//Class object - String n=new String ("karthikeya")
//Along with string we are having two more clases one is stringbuffer and another one is stringbuilder
// No literal declarion for stringBuffer and stingBuilder
// if the content is fixed and wont change frequently then we should go for String
//If the content is not fixed and keep on changing but thread safty is required then we should go for stringbuffer
//If the content is not fixed and keep on changing but thread safty is not required then we should go for stringbuilder 
//thread safe : when multiple operations are taken place on the same page (ex: registration form) during that time security purpose
//mutable: mutable objects are concerned, you can perform modifications to them,stringbuffer and stringbuilder are examples and less memory consumption
//immutable  : Immutable objects are like constants. You can�t modify them once they are created, string class is example,If you try to modify them, a new object will be created with modified content. This may cause memory and performance issues if you are performing lots of string modifications in your code. To overcome these issues, StingBuffer and StringBuilder classes are introduced in java.