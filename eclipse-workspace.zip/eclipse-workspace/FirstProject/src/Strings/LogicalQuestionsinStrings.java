package Strings;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.swing.Spring;

public class LogicalQuestionsinStrings {


//Palindrome 
/*public static void main(String[] args) 
{
	String str="madam";
	String rev="";
	
	for (int i=0; i<str.length(); i++)
	{
		rev=rev+str.charAt(i);		
	}
	if(str.equals(rev))
	{
		System.out.println(str+" is a palindrome");
	}
	else
	{
		System.out.println(str+" is not a palindrome");
	}
 
}*/

	
//String reverse
	/*public static void main(String[] args) 
    { 
		String str = "KarthikeyaReddy";
		StringBuffer str1=new StringBuffer();
		str1.append(str);
		StringBuffer output = str1.reverse();
		System.out.println(output);
    }*/
	
	/*public static void main(String[] args) 
    { 
		String str = "KarthikeyaReddy";
	    char[] output = str.toCharArray();
	    for(int i= output.length-1; i>=0; i--)
	    {
	    	System.out.println(output[i]);
	    }
    }*/

	
	
//String to Array	
	/*public static void main(String args[])
	{
		String str = "Karthi keya Reddy";
		//char strArray[] = str.toCharArray();
		String strArray[]=str.split("");	
		for(int i=0; i < strArray.length; i++)
		{
			System.out.println(strArray[i]);
		}
	}*/


//Integer to String
	/*public static void main(String args[])
	{
		int number = -782;
		String output = Integer.toString(number)+"JHJKHKJ";
		System.out.println(output);
	}*/
	
	
//String to Integer
	/*public static void main(String args[])
	{
		String number = "10041";
		int output = Integer.parseInt(number)+12456;
		System.out.println(output);
	}*/
	
	
//count the occurrence of each character in a string in java
	/*public static void main(String[] args) 
	{
	String str ="karthikeyareddy"; 
	HashMap<Character, Integer> output=new HashMap<Character, Integer>();
	char[] str1 = str.toCharArray();
	for(char current : str1)
	{
		if(output.containsKey(current))
		{
			output.put(current, output.get(current)+1);
		}
		else
		{
			output.put(current, 1);
		}
	}
	System.out.println(output);
	}*/
	

	
//Most frequent element and how many times it occres	
	/*public static void main(String[] args) 
	{
		String str ="karthikeyareddyvonteddu"; 
		 char maxFrequentCharacter = 0;
		 char[] str1 = str.toCharArray();
		 for (int i = 0;i<str.length()-1;i++)
	     {
	     for (int j =i+1;j<str.length();j++)
	     {
		 if (str1[i]==(str1[j]))
		 {
			 maxFrequentCharacter = str1[i];
			 
		 }
	  }
    }
		 System.out.println("Frequent number is "+maxFrequentCharacter);
	
    }*/



//Finding Duplicate Elements 
	/*public static void main(String[] args) 
	{
		 String str="karthikeyareddyvonteddu";
		 char[] output = str.toCharArray();
		 for(int i=0; i<output.length-1; i++)
		 {
			 for(int j=i+1; j<output.length; j++)
			 {
				 if(output[i] == output[j])
				 {
					 System.out.println("duplicate element is :"+ output[j]);
					 break;
				 }
			 }
		 }
	}*/
	
	
//Missing character in string	
	/*public static void main(String[] args) 
	  {
		 String str="karthikeyareddyvonteddu";
		 int it=0;
		 char[] output = str.toCharArray();
		 for(int i=0; i<output.length-1; i++)
		 {
			if(output[i] == 'e')
			{
				it++;
			}
		 }
		 if(it == 0)
		 {
			System.out.println("false");
		 }
		 else
		 {
			 System.out.println("true");
		 }
	   }*/
}


	



