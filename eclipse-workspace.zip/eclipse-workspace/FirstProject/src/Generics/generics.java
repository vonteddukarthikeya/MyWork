package Generics;

public class generics {

}


/*Main purpose of generics is to provide "Type safety" and to resolve "type casting" problems

Type Safety : Array objects by default typesafe, i.e. we declare String Array we can insert only String Objects. 
              By mistake if we are trying to insert any other element we will get compile time error.
              Arrays have type safety the main advantage and we can give the guaranty for the type of elements presents inside the array
              String array can contain only string objects and integer array can contain only integer objects

  
              If we go for collections we dont have type safety by default, in collections we can store any kind of data. 
              to get type safety for collections we use generics. 
              example : 
              ArrayList<String> kkr=new ArrayList<String>();
              in the above example also we can store only string type of objects, if we add other than string we get compile time error
              

              when we provide type safety for collections automatically type casting problem will be resolved
              
 
ArrayList<T> kkr=new ArrayList<>();
where "T" is type parameter

methods : get,set,compare,equals
*/