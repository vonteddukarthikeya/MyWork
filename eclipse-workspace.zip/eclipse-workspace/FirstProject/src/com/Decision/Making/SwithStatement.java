package com.Decision.Making;

public class SwithStatement 
{
 static int a=6;
	public static void main(String[] args) 
	{
		switch (a)
		{
		case 1:
			System.out.println("print 1");
			break;
		case 2:
			System.out.println("print 2");
			break;
		case 3:
			System.out.println("print 3");
			break;
		case 4:
			System.out.println("print 4");
			break;
		case 5:
			System.out.println("print 5");
			break;
			
		default:
			System.out.println("enter number a between 1 and 5");
			break;
		}

	}

}

// For switch we have to use switch key word, in switch it contains cases, writing some options in cases, which case is selected that case is executed.it is like multiple choice questions
/*syntax
switch(argument/variable)
{
case 1: here we can give string/ character/ number instead of "1" 
	//code
break;
case n:
	//code
break;

default:
  //code
break;   

}*/