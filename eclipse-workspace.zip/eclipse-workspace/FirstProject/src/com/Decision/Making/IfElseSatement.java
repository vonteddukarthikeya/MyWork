package com.Decision.Making;

public class IfElseSatement 
{
 static int a=80; 
 static int b=30;
		 
	public static void main(String[] args) 
	{
		if (b>a)
		{
			System.out.println("b is greater than a");
		}
		else
		{
			System.out.println("a is greater than b");
		}

	}

}


// if so and so condition is true means executes first block(if) if condition is false means second block(else) will execute
/*syntax
if (expression/condition)
{
	statement 1; 
else
{
	statement 2;
}
}*/