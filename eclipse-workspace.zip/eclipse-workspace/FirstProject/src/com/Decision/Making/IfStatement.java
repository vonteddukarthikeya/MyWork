package com.Decision.Making;

public class IfStatement 
{

	static int a=20;
	static int b=30;
	
	
	public static void main(String[] args) 
	{
		if (b>a)
		{
		System.out.println("b is greater");
		}
	}

}

//In decision making we take the decisions weather true or false. here we have some statements if,if else,else if and switch
// if statement always returns true or false, if we want to check any condition we use this. (if statement means if this is ok then do that that's it) if not means not saying anything.not looking for any alternative

/*syntax
		if (expression/condition)
		{
			statement 1;
			statement 2;
		}*/