package com.Decision.Making;

public class ElseIfStatement 
{
 static int a=30;
 static int b=30;
 
	public static void main(String[] args) 
	{
		if (b>a)
		{
			System.out.println("b is greater than a");
		}
		else if (b<a)
		{
			System.out.println("a is greater than b");
		}
		else 
		{
			System.out.println("both a and b are equal");
		}
	}

}

//keep on checking, checking for all the conditions (if we want to check for more than one condition we go for else if)
/*syntax
if (expression/condition)
{
	statement 1; 
}
else if (expression/condition)
{
	statement 2;
}
else
{
    statement 2; 
}
}*/