package com.Opps;

public class ConstructorsParentClass 
{
	
	
	int Eno;
	String Ename;
	char chr;
 

	public ConstructorsParentClass(int Eno, String Ename, char chr) 
	{
		this.Eno =Eno;//this. is used to represent the current class objects
		this.Ename =Ename;
		this.chr = chr;
	}

	public ConstructorsParentClass(int Eno, String Ename) 
	{
		this.Eno =Eno;
		this.Ename =Ename;
	}
	
	public ConstructorsParentClass(int Eno)
	{
		this.Eno =Eno;
	}
	
	public ConstructorsParentClass()
	{
		
	}
	
	public static void main(String[] args) 
	{
	
		ConstructorsParentClass CPC =new ConstructorsParentClass(114142,"karthi",'V');
		System.out.println(CPC.Eno);
		System.out.println(CPC.Ename);
		System.out.println(CPC.chr);
		
		ConstructorsParentClass CPC1 =new ConstructorsParentClass(114143,"keya");
		System.out.println(CPC1.Eno);
		System.out.println(CPC1.Ename);
		
		ConstructorsParentClass CPC2 =new ConstructorsParentClass(114144);
		System.out.println(CPC2.Eno);
		
	}

}

//purpose of constructor : initialize the object state
//while creating class object, left side we called class and right side we called as constructor
//this() is used to call the constructor with in a constructor in same class
//super() is used to call the constructor with in a constructor in different class
//this. is used to call the current class objects
//super. is used to call the parent class objects in child class 



