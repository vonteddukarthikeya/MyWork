package com.Opps;

import com.hdfcbank.carloans.Hdfc;
import com.hdfcbank.carloans.Icici;
import com.hdfcbank.carloans.Rbi;

public class Polymorphism 
{
 static Rbi i;
 
	public static void main(String[] args) 
	{
		i =new Icici();
		i.withdrawl();
		
		i=new Hdfc();
		i.withdrawl();
		
	}

}

//making more than one forms (ex: Allrounder), it can act like many things.Applicable to object and method level, using single method or object we can use it multiple ways.
//Object using from parent to child class in three ways.
//Object using from interface (rbi) to child class (icici, hdfc)
//Methods using : overloading(static polymorphism) with in the classes with different signatures (and here execution takes place by the compiler) and overriding(dynamic polymorphism) across the classes (and here execution takes place by the run time) 