package com.Opps;

public class OverridingParentClass 
{
	
	public void workhard() 
	{
		System.out.println("wakeup early,go to college");
	}

	public void care() 
	{
		System.out.println("utmost care");
	}
	
	public static void main(String[] args) 
	{
		OverridingParentClass opc =new OverridingParentClass();
		opc.workhard();
		opc.care();
				

	}

}

// Same method name but modifying inner functionality is known as overriding (inheritance concept), override occurs between the classes.
// both in parent class and child  class we are having same method name "workhard", but different in internal logic, when there is relation between parent and child class it is overriding
