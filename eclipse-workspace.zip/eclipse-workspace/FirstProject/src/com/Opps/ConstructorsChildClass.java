package com.Opps;

public class ConstructorsChildClass extends ConstructorsParentClass
{
	
	int EmpId;
	String ESubject;
	
public ConstructorsChildClass(int Eno, String Ename, char chr, int EmpId, String ESubject) 
{
		super(Eno, Ename, chr);// super. is used to access any parent class in child class
		this.EmpId = EmpId;
		this.ESubject = ESubject;
		
}
	public static void main(String[] args) 
	{
		ConstructorsChildClass CCC =new ConstructorsChildClass(114145,"Vonteddu",'K',123,"Testing");
		System.out.println(CCC.Eno);
		System.out.println(CCC.Ename);
		System.out.println(CCC.chr);
		System.out.println(CCC.EmpId);
		System.out.println(CCC.ESubject);
		
	
 
	}

}
