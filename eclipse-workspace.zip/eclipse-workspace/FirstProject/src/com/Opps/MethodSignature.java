package com.Opps;

public class MethodSignature 
{

	
	public static void add(int a,int b)// here add(int,int) are signatures (Method name followed by the parameter types)
	{
		
	}
	
	//public static void sub(int e,float g)// sub(int,float) 
	{
		
	}
	
	//public static void sub(int e,float g)// in a class no 2 methods should have the same signature otherwise compilation error
	{
		
	}
	
	public static void mul(int d,float c)// mul() 
	{
		
	}
	
	public static void div(String d,float c)// div(string, float)
	{
		
	}
	public static void main(String[] args) 
	{
		

	}

}

//same method name but parameters are different is called overloading