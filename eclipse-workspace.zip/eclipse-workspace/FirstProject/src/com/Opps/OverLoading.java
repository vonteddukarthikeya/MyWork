package com.Opps;

public class OverLoading
{

	public void m1(int a,float b)
	{
		System.out.println("Int & float values are :" + a + " "+ b);
	}
	
	public void m1(float a,int b)
	{
		System.out.println("float & Int values are :" + a + " "+ b);
	}
	
	public void m1(int i)
	{
		System.out.println(i);
	}
	
	public void m1(float f)
	{
		System.out.println(f);
	}
	
	
	public void m1(String str)
	{
		System.out.println(str);
	}
	
	public static void main(String[] args) 
	{
		OverLoading ovr=new OverLoading();
		ovr.m1(10, 20.34f);
		ovr.m1(20.34f, 20);
		ovr.m1(10); // Automatic promotion
		ovr.m1(10.45f);
		ovr.m1("Karthik");
	}

}


// Argument should not be same but method name should be same then it is applicable to method overloading, with in the class 

// Automatic promotion in data types : (byte,short,int,long,float,double) if the highest data type is not available at that time we get compilation error

// object hold all the types and classes (byte,short,int,long,float,double, String,Integer, Number)