package com.Opps;

public class OverridingChildClass extends OverridingParentClass
{
	public void workhard() 
	{
		System.out.println("wakeup anytime,go to bar");
	}

	public void love() 
	{
		System.out.println("i am in love");
	}

	public static void main(String[] args) 
	{
		
		OverridingChildClass occ =new OverridingChildClass();
		occ.workhard();
		occ.love();
		occ.care();
		
		OverridingParentClass opc =new OverridingParentClass();
		opc.workhard();
		opc.care();
	
		OverridingParentClass pc =new OverridingChildClass();
		pc.workhard();
		pc.care();
		
		
	}

}
