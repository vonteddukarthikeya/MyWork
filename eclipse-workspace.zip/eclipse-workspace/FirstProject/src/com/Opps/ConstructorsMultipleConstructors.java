package com.Opps;

public class ConstructorsMultipleConstructors 
{

	int Eno;
	String Ename;
	char chr;
 

	public ConstructorsMultipleConstructors(int Eno, String Ename, char chr) 
	{
		this(114143,"Keya");
		this.Eno =Eno;
		this.Ename =Ename;
		this.chr = chr;
		System.out.println(this.Eno);
		System.out.println(this.Ename);
		System.out.println(this.chr);
	}

	public ConstructorsMultipleConstructors(int Eno, String Ename) 
	{
		this(114144);
		this.Eno =Eno;
		this.Ename =Ename;
		System.out.println(this.Eno);
		System.out.println(this.Ename);
	}
	
	public ConstructorsMultipleConstructors(int Eno)
	{
		this.Eno =Eno;
		System.out.println(this.Eno);
	}
	
	public ConstructorsMultipleConstructors()
	{
		
	}
	
	public static void main(String[] args) 
	{

		ConstructorsMultipleConstructors CMC =new ConstructorsMultipleConstructors(114142,"karthi",'V');	

	}

}
