package com.Opps;

public class Debugging 
{
	int i=0,sum=0;
	public int addition() 
	{
		for (i=0;i<=5;i++)
		{
			sum=sum+i;
		}
		return sum;
	}

	public static void main(String[] args) 
	{
		Debugging debug =new Debugging();
		int count =debug.addition();
		System.out.println(count);

	}

}

//step into (F5) -- executes one by one step (inside the function call debug all the lines line by line)
//step over (F6) -- executes the function in one shot and goes to next to debug where it is (by pases)
//windows -- show view
//run --- debug / debug as