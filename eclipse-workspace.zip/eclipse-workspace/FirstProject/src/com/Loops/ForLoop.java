package com.Loops;

public class ForLoop 
{
	 static int n=1;
	 static int times=5;

	public static void main(String[] args) 
	{
		for (n=1; n<=times; n++)
		{
			System.out.println("This is karthik:" + n);
		}

	}

}


//in a single frame we give  initialization;condition;increment/decrement with ";" seperation

//syntax
/*for (initialization;condition;increment/decrement)
 {
 statement(s);
 }
 */