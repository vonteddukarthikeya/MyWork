package com.Loops;

public class WhileLoop 
{
 static int n=1;
 static int times=5;
	public static void main(String[] args) 
	{
		
while(n<=times)
{
	System.out.println("Hi this is karthik:"+ n);
	n++;
}
	}

}

// all loops are used for iteration purpose (while,do while,for,for each)
//here first checks the condition and execute the statement

//syntax

/* initialization (we need to initialize the variables)
 while() 
 
{
	statement(s);
	Incrementation;
}*/