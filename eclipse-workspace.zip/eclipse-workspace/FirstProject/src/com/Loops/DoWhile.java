package com.Loops;

public class DoWhile 
{
 static int n=1;
 static int times=5;
 
	public static void main(String[] args) 
	{
	
		do
		{
			System.out.println("This is karthik:" + n);
			n++;
		}
		while(n<=times);

	}

}


//First executes the statements and then checks the condition

//syntax
/*do
{
statement(s);
}
while(condition);*/