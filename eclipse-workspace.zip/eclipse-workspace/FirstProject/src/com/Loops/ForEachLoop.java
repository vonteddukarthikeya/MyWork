package com.Loops;

public class ForEachLoop 
{

	public static void main(String[] args) 
	{
		

	}

}


//when dynamically size is increasing then we go for Foreach.