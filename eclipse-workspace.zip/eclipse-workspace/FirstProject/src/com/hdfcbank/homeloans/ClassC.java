package com.hdfcbank.homeloans;

import com.hdfcbank.personalloans.ClassA;

public class ClassC extends ClassA
{
	public void m3()
	{
	System.out.println(" Hi this is Class C");
	}
	
	public static void main(String[] args) {
		
		ClassC c=new ClassC();
		c.m3();
		c.m1();
		System.out.println(c.x);
	
		 ClassA a=new ClassA();
		 a.m1();
		 System.out.println(a.x);
	}

}

