package com.hdfcbank.homeloans;

import com.hdfcbank.carloans.Inheritance_A;
import com.hdfcbank.carloans.Inheritance_B;

public class Inheritance_C extends Inheritance_B
{

	public void m3()
	{
		System.out.println("Hi this is m3 method in C class");
	}
	
	public static void main(String[] args) 
	{
		Inheritance_C insC=new Inheritance_C();
		insC.m3();
		insC.m1();
	}

}
