package com.hdfcbank.carloans;

// Constructors are used to initialize objects state
//Keyword 'THIS' in Java is a reference variable that refers to the current object. It can be used to refer current class instance variable. It can be used to invoke or initiate current class constructor. It can be passed as an argument in the method call.

public class Constructor 
{
	
 int EmpId;
 String Name;
 float Value;
 char Char;
 
 

	public Constructor(int EmpId, String Name, float Value, char Char) 
	{
		this.EmpId=EmpId;
		this.Name=Name;
		this.Value=Value;
		this.Char=Char;
		
    }


	public Constructor(int EmpId, String Name, float Value) 
	{
		this.EmpId=EmpId;
		this.Name=Name;
		this.Value=Value;
	}


	public Constructor(int EmpId, String Name) 
	{
		this.EmpId=EmpId;
		this.Name=Name;
	}


	public static void main(String[] args) {
		
		Constructor cons1=new Constructor(114142,"Vonteddu Karthikeya Reddy",31000.000f,'K');
		Constructor cons2=new Constructor(114143,"Vonteddu Mohana Reddy",61000.000f);
		Constructor cons3=new Constructor(114144,"Vonteddu Sasikala Reddy");
		
		
		System.out.println(cons1.EmpId);
		System.out.println(cons1.Name);
		System.out.println(cons1.Value);
		System.out.println(cons1.Char);
		
		System.out.println(cons2.EmpId);
		System.out.println(cons2.Name);
		System.out.println(cons2.Value);

		
		System.out.println(cons3.EmpId);
		System.out.println(cons3.Name);

		
	
		
	}

}
