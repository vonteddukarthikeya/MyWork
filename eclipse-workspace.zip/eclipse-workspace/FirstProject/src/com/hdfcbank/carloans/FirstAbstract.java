package com.hdfcbank.carloans;

public abstract class FirstAbstract 
{
 public void m1()// Concrete methods
 {
 System.out.println("Hi i am m1 concrete behavoiur");
 }
 
 public abstract void m2(); // adstract methods
}

/*land and building, property given to child

land and building, child can reuse the same property which is given by dad is called inheritance
where land can be changed to construct the building,here land is called interface and building is concrete 
Concrete Method is not changeable and Abstract method is must overridden*/