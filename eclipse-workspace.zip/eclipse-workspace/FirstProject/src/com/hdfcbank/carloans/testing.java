package com.hdfcbank.carloans;

public class testing {

	static int x;  // this is declaring 
	static testing a;
	static testing c;
	int i=10; // Instance Variable
	float f=11.23f; // Instance Variable
	byte b=45; // Instance Variable
	static String str="karthik";
	
	static float roi=8.5f; // Static Variable
	
	public void m1() // Instance Method
	{
		System.out.println(i); // instance variable by directly
		m1(); // instance method by directly
		
		
		System.out.println(roi); //static variable by directly
		System.out.println(testing.roi); //static variable by indirectly through class name
		m2(); // static method by directly
		testing.m2(); // static method by indirectly through class name
	}

	
	public static void m2() // Static Method
	{
		x=100;
		c=new testing();
		System.out.println(c.f);   // instance variable by class reference 
		c.m1(); // instance method by class reference
		
		System.out.println(roi); //static variable by directly
		System.out.println(testing.roi); //static variable by indirectly through class name
		m2(); // static method by directly
		testing.m2(); // static method by indirectly through class name
	}
	
	
	public static void main(String[] args) 
	{
		a = new testing();
		System.out.println(a.f);   // instance variable by class reference
		a.m1(); // instance method by class reference

		System.out.println(roi); //static variable by directly
		System.out.println(testing.roi); //static variable by indirectly through class name
		m2(); // static method by directly
		testing.m2(); // static method by indirectly through class name
        
        System.out.println(str.length());
	}

}
