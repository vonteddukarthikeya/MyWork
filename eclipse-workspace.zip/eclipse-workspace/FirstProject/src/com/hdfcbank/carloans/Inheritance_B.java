package com.hdfcbank.carloans;

public class Inheritance_B extends Inheritance_A
{

	public void m2()
	{
		System.out.println("Hi this is m2 method in B class");
	}

	public void tetsingM2()
	{
		System.out.println("Hi this is tetsingM2 method in testingB class");
	}
	
	public void tetsingM1()
	{
		System.out.println("Hi this is tetsingM1 overridden in B class");
	}
	
	public static void main(String[] args) 
	{
		Inheritance_A insA=new Inheritance_A();
		insA.m1();
		insA.tetsingM1(); 
		
		Inheritance_B insB=new Inheritance_B();
		insB.m2();
		insB.m1();
		insB.tetsingM2();
		insB.tetsingM1();
		
		Inheritance_A x=new Inheritance_B(); 
		x.tetsingM1();

	}
}


/*in IS A relation we get parent and child methods
In HAS A relation we get particular class objects only we get for the created method*/