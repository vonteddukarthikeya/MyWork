package com.hdfcbank.carloans;

public class Inheritance_A 
{
	
	public static void m1()
	{
		System.out.println("Hi this is m1 method in A class");
	}
	
	public void tetsingM1()
	{
		System.out.println("Hi this is tetsingM1 method in testingA class");
	}
	

	public static void main(String[] args) 
	{
		Inheritance_A insA=new Inheritance_A();
		insA.m1();
		insA.tetsingM1();

		
		
	}

}
