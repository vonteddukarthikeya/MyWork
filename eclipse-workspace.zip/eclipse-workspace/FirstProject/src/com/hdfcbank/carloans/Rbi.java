package com.hdfcbank.carloans;

public interface Rbi 
{
 public void withdrawl(); // interface 100% abstract methods
}
