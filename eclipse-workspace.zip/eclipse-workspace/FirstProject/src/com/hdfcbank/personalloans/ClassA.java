package com.hdfcbank.personalloans;

public class ClassA 
{
	public int x=100;
	
	public void m1() 
	{
	System.out.println(" Hi this is class A");
	}
	
	public static void main(String[] args) // main method
	{
	/*creating class object*/
    ClassA/*class*/ a/*reference variable*/=new/*keyword*/ ClassA();/*constructor*/
    a.m1();
    System.out.println(a.x);

	}

}

//syntax
//AM NAM class classname
// AM NAM datatype variable= value;
//AM NAM returntype methodname (arguments/parameters) --- if you are not returning anything then give as "void", return types like "string,integer,object"
//Concrete and abstract behaviors in abstract class