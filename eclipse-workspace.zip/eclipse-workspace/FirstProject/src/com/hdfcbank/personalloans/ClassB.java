package com.hdfcbank.personalloans;

public class ClassB extends ClassA
{

	public void m2()
	{
	System.out.println(" Hi this is class B");
	}

	public static void main(String[] args) 
	{
		
		  ClassB b=new ClassB();
		  b.m2();
		  b.m1();
		  System.out.println(b.x);
		
		  ClassA a=new ClassA();
		  a.m1();
		  System.out.println(a.x);

	}

}
 