package Insightsc3m.Tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import jxl.Sheet;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
 
public class ContentTesting 
{
	public static WebDriver driver;
	// Providing insights login credentials
	public static  String username="nagasumm"; //User Name
	public static  String password="Altria!222"; //Password
	public static  String accountnumber="46683"; //Account Number	
	
	//Click events
	public static void login(String username, String password, String accountnumber) throws InterruptedException, BiffException, IOException, RowsExceededException, WriteException
	{
		  driver.get("https://qa1.insightsc3m.com/");//Application URL
		  driver.findElement(By.id("UserIdentifierClaim")).sendKeys(username);//Passing UserName Id
		  Thread.sleep(10000);
		  driver.findElement(By.id("UserPasswordClaim")).sendKeys(password);//Passing Password Id
		  Thread.sleep(20000);
		  driver.findElement(By.id("lnklogin")).click();// Login Click Event
		  Thread.sleep(20000);
		  driver.findElement(By.id("txtSearch")).sendKeys(accountnumber);//Entering Account Number
		  Thread.sleep(20000);
		  driver.findElement(By.id("btnGo")).click();//Go icon click event
		  Thread.sleep(20000);
	 }
	
	public static void NavigatetoReportCenter() throws InterruptedException, BiffException, IOException, RowsExceededException, WriteException {
		driver.findElement(By.xpath("//*[@id='btnReportsMaster']")).click();// click on Reports Master in left channel
		Thread.sleep(20000);
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}	
	
	public static void main(String[] args) throws InterruptedException, BiffException, IOException, RowsExceededException, WriteException 
	{
		ExcelReadWrite.readPath =  "D:\\Selenium\\Excel Inputs\\Content.xls"; //Read Path
		ExcelReadWrite.writePath = "D:\\Selenium\\Excel Outputs\\ContentResult.xls"; //Write Path
		
		ExcelReadWrite.CopyContentToOutputFile();
		
		System. setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe"); //Run the application in Chrome browser
		driver = new ChromeDriver();
		driver.manage().window().maximize(); //Maximize the browser
		
		login(username, password, accountnumber); //login and account selection
		Thread.sleep(10000);
		
		NavigatetoReportCenter();		
		
		Sheet currentSheet = ExcelReadWrite.GetSheet();
		String idSelector = "";                                              
		
		for(int row = 1; row < currentSheet.getRows(); row++) 
		{
			ExcelReadWrite.LastRowIndex++;
			 String module = ExcelReadWrite.GetCellData(currentSheet, row, 0);			
			 
			 switch(module) {
			 
		
				 
			 case "My Reporting Center - Payments Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC001-2']/h5";
				 break;
				 
			 case "My Reporting Center - Payments Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC001-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Payments Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC001-2']/p[2]/a";
				 break;
			
				 
				 
				 
			 case "My Reporting Center - Price Promotions Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC017-2']/h5";
				 break;
				 
			 case "My Reporting Center - Price Promotions Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC017-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Price Promotions Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC017-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - Product Promotions Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC015-2']/h5";
				 break;
				 
			 case "My Reporting Center - Product Promotions Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC015-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Product Promotions Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC015-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - Mobile Coupon Redemption Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC004-2']/h5";
				 break;
				 
			 case "My Reporting Center - Mobile Coupon Redemption Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC004-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Mobile Coupon Redemption Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC004-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - Special Return Programs Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC005-2']/h5";
				 break;
				 
			 case "My Reporting Center - Special Return Programs Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC005-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Special Return Programs Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC005-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - Initiative Summary Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC006-2']/h5";
				 break;
				 
			 case "My Reporting Center - Initiative Summary Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC006-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Initiative Summary Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC006-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - Retail Elections Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC009-2']/h5";
				 break;
				 
			 case "My Reporting Center - Retail Elections Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC009-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Retail Elections Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC009-2']/p[2]/a";
				 break;
			
				 
				 
				 
			 case "My Reporting Center - Scan Data Submissions Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC011-2']/h5";
				 break;
				 
			 case "My Reporting Center - Scan Data Submissions Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC011-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - Scan Data Submissions Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC011-2']/p[2]/a";
				 break;
				 
				 
				 
				 
			 case "My Reporting Center - PCMA Maintenance Qualifier Report Header" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC012-2']/h5";
				 break;
				 
			 case "My Reporting Center - PCMA Maintenance Qualifier Report Content" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC012-2']/p[1]";
				 break;
				 
			 case "My Reporting Center - PCMA Maintenance Qualifier Report Link" :
				 idSelector = ".//*[@id='div-RPTCTR_SE_ROW_RC012-2']/p[2]/a";
				 break;
				 
				 
			 }			 
			 
			 String ActualMyReportingCenter=driver.findElement(By.xpath(idSelector)).getText();			 
			 ExcelReadWrite.CheckContentText(currentSheet, row, idSelector, ActualMyReportingCenter);
		}
		
		ExcelReadWrite.PieChartReport();		
		ExcelReadWrite.WriteExcel();
		driver.close();
		ExcelReadWrite.OpenOutputExcel();
	}
	
 }
	
	
	



	

